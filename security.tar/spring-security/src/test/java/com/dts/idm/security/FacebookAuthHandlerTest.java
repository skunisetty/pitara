package com.dts.idm.security;

import com.dts.common.StreamUtils;
import com.dts.idm.dto.User;
import com.dts.idm.service.ServiceException;
import com.dts.idm.service.UserService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.inject.Inject;
import java.io.IOException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring-security.xml",
		"classpath:spring-security-test.xml" })
public class FacebookAuthHandlerTest {
	@Inject
	private FacebookAuthHandler handler;

	@Autowired
	private UserService userService;

	@Test
	public void testHandlingSessionDataWithAutoCreateTrue() throws IOException,
            ServiceException {
		String testFile = "data/facebook.auth";
		byte[] jsonData = StreamUtils.loadContent(testFile);
		OAuthToken token = new OAuthToken();
		token.setOAuthData(jsonData);
		UserDetails userDetails = handler.retrieveUser(token);
		Assert.assertNotNull(userDetails);
		User udUser = ((UserDetailsImpl) userDetails).getUser();
		User created = userService.findUserByUserId(userDetails.getUsername());
		Assert.assertEquals(udUser, created);
		Assert.assertTrue(this.userService.delete(udUser.getId()));
	}

	@Test
	public void testHandlingSessionDataWithAutoCreateFalse()
			throws IOException, ServiceException {
		this.handler.setCreateAccountIfAuthenticated(false);
		String testFile = "data/facebook.auth";
		byte[] jsonData = StreamUtils.loadContent(testFile);
		OAuthToken token = new OAuthToken();
		token.setOAuthData(jsonData);
		try {
			handler.retrieveUser(token);
			Assert.fail();
		} catch (Exception ae) {
			Assert.assertTrue(UsernameNotFoundException.class.isAssignableFrom(ae.getClass()));
		}
		
		this.handler.setCreateAccountIfAuthenticated(true);
	}
}
