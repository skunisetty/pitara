package com.dts.idm.security;

import com.dts.idm.dto.Authorization;
import com.dts.idm.dto.User;
import com.dts.idm.service.ServiceException;
import com.dts.idm.service.TicketService;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: sanjeev
 * Time: 5:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class TicketServiceMock implements TicketService {
    private static final Log log = LogFactory.getLog(TicketServiceMock.class);
    private Map<String, Authorization> ticketMap = new HashMap<String, Authorization>();

    @Override
    public String createServiceToken(Authorization auth)
            throws ServiceException {
        String token = Base64
                .encodeBase64URLSafeString((System.nanoTime() + "").getBytes());
        log.debug("auth " + auth + " token " + token);
        ticketMap.put(token, auth);
        return token;
    }

    @Override
    public String createServiceToken(User user) throws ServiceException {
        return this.createServiceToken(toAuth(user));
    }

    @Override
    public String createServiceToken(User user, int expiresAt)
            throws ServiceException {
        return this.createServiceToken(user) + ":" + expiresAt;
    }

    @Override
    public User extractUserInfo(String base64Encoded) throws ServiceException {
        int expIndex = base64Encoded.indexOf(":");
        if (expIndex > 0) {
            base64Encoded = base64Encoded.substring(0, expIndex);
        }
        return toUser(ticketMap.get(base64Encoded));
    }

    @Override
    public Authorization validate(String base64Encoded) throws ServiceException {
        log.debug("validating: " + base64Encoded);
        int expIndex = base64Encoded.indexOf(":");
        if (expIndex > 0) {
            base64Encoded = base64Encoded.substring(0, expIndex);
        }
        log.debug("exp removed validating: " + base64Encoded);
        log.debug("exp removed validating: " + base64Encoded);
        return this.ticketMap.get(base64Encoded);
    }

    @Override
    public int invalidate(String base64Encoded) throws ServiceException {
        if (this.ticketMap.remove(base64Encoded) != null) return 1;
        return 0;
    }


    static public User toUser(Authorization auth) {
        User u = new User();
        u.setId(Long.valueOf(auth.getUserId()));
        u.setUserId(auth.getPrincipal());
        u.setPassword(auth.getSecret());

        return u;
    }

    static public Authorization toAuth(User user) {
        Authorization auth = new Authorization();

        auth.setUserId(user.getId());
        auth.setPrincipal(user.getUserId());
        auth.setSecret(user.getPassword());

        return auth;
    }
}
