package com.dts.idm.security.web;

import com.dts.common.CollectionUtil;
import com.dts.idm.security.AuthScheme;
import junit.framework.Assert;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.AuthenticationException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Properties;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:idm-security.xml",
		"classpath:spring-security-test.xml" })
public class IdmAuthenticationEntryPointTest {
	private static final Log log = LogFactory
			.getLog(IdmAuthenticationEntryPointTest.class);

	@Autowired
	private IdmAuthenticationEntryPoint idmAuthFailureHandler;

	@SuppressWarnings("serial")
	@Test
	public void testBasic401() throws IOException, ServletException {
		AuthScheme authScheme = idmAuthFailureHandler.getAuthScheme();
		idmAuthFailureHandler.setAuthScheme(AuthScheme.BASIC);
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();

		this.idmAuthFailureHandler.commence(request, response,
				new AuthenticationException(null) {
				});
		this.idmAuthFailureHandler.setAuthScheme(authScheme);
		Assert.assertEquals(HttpServletResponse.SC_UNAUTHORIZED, response
                .getStatus());

		String authHeader = String.valueOf(response
				.getHeader(IdmAuthenticationEntryPoint.WWW_AUTHENTICATE));
		log.debug("authHeader: " + authHeader);
		Assert.assertTrue(StringUtils.isNotBlank(authHeader));
		Properties props = CollectionUtil.split(authHeader, ",");
		Assert.assertNotNull(props);
		log.debug("header to props: " + props);
		Assert.assertEquals(idmAuthFailureHandler.getRealmName(), props
                .get("Basic realm"));
	}

	@SuppressWarnings("serial")
	@Test
	public void testFormAuth() throws IOException, ServletException {
		AuthScheme authScheme = idmAuthFailureHandler.getAuthScheme();
		idmAuthFailureHandler.setAuthScheme(AuthScheme.FORM);
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();

		this.idmAuthFailureHandler.commence(request, response,
				new AuthenticationException(null) {
				});
		this.idmAuthFailureHandler.setAuthScheme(authScheme);
		Assert.assertEquals(HttpServletResponse.SC_OK, response.getStatus());

		Assert.assertNull(response
                .getHeader(IdmAuthenticationEntryPoint.WWW_AUTHENTICATE));

		log.info("redirect url: " + response.getRedirectedUrl());
		Assert.assertTrue(response.getRedirectedUrl().endsWith(
                this.idmAuthFailureHandler.getLoginUrlAuthEntryPoint()
                        .getLoginFormUrl()));
	}
}
