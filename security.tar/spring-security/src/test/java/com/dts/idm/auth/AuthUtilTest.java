package com.dts.idm.auth;

import org.junit.Assert;
import org.junit.Test;
import static com.dts.idm.auth.AuthUtil.*;

public class AuthUtilTest 
{
	@Test
	public void testHashPassword() throws Exception
	{
		String userName = "sanjeev";
		String password = "mishra";
		String s = hashPassword(userName, password);
		Assert.assertEquals("nbDezqPBonVVz5PEePfbeTrr7yLLsruG91ob4R/PhIg=", s);
	}
	
	@Test
	public void testHexToInt()
	{
		String bytes = "0123456789ABCDEFabcdef";
		int[] values = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 10, 11, 12, 13, 14, 15 };
		for(int i = 0; i < bytes.length(); i++)
		{
			Assert.assertEquals(hexCharToInt(bytes.charAt(i)), values[i]);
		}
		
	}
	
	@Test
	public void testPack()
	{
		String test = "C5D1A8930012650A20";
		byte[] expected = new byte [] { (byte)0xc5, (byte)0xd1, (byte)0xa8, (byte)0x93, 0x00, 0x12, 0x65, 0x0a, 0x20};
		byte[] pack = pack(test);
		for(int i = 0; i < pack.length; i++)
			Assert.assertEquals(expected[i], pack[i]);
	}
	
	@Test
	public void testMarshal()
	{
		byte[] a = new byte[] { 0, 1, 2 }, b = new byte[] { 3, 4, 5, 6 }, c = new byte[] { 7, 8, 9, 10 };
		byte[] expected = new byte[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		byte[] result = marshal(a, b, c);
		for(int i = 0; i < result.length; i++)
			Assert.assertEquals(expected[i], result[i]);
	}
	

}
