package com.dts.idm.security;

import com.dts.common.StreamUtils;
import com.dts.idm.dto.User;
import com.dts.idm.service.UserService;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.ProviderNotFoundException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring-security.xml",
		"classpath:spring-security-test.xml" })
public class OAuthAuthenticationProviderTest {
	@Autowired
	private OAuthAuthenticationProvider provider;

	@Autowired
	private FacebookAuthHandler facebookAuthHandler;
	
	@Autowired
	private UserService userService;

	
	public void testUnsupportedToken() {
		Authentication authentication = new UsernamePasswordAuthenticationToken(
				"foo", "bar");
		Authentication auth = provider.authenticate(authentication);
		Assert.assertNull(auth);
	}

	@Test
	public void testUnsupportedProvider() {
		OAuthToken oAuthToken = new OAuthToken();
		oAuthToken.setServiceProviderId("unsupported");
		com.dts.idm.security.OAuthAuthenticationToken authentication = new com.dts.idm.security.OAuthAuthenticationToken(
				oAuthToken);

		try {
			provider.authenticate(authentication);
		} catch (AuthenticationException ae) {
			Assert.assertTrue(ProviderNotFoundException.class
					.isAssignableFrom(ae.getClass()));
		}
	}

	@Test
	public void testFacebook() throws Exception {
		OAuthToken oAuthToken = new OAuthToken();
		oAuthToken.setServiceProviderId(this.facebookAuthHandler
				.getProviderId());
		byte[] oAuthData = StreamUtils.loadContent("data/facebook.auth");
		oAuthToken.setOAuthData(oAuthData);
		OAuthAuthenticationToken authentication = new OAuthAuthenticationToken(
				oAuthToken);

		Authentication auth = provider.authenticate(authentication);
		Assert.assertNotNull(auth);
		OAuthAuthenticationToken authenticated = (OAuthAuthenticationToken) auth;
		UserDetailsImpl ud = (UserDetailsImpl) authenticated.getPrincipal();
		User u = ud.getUser();
		Assert.assertNotNull(u);
		assertMatch(oAuthData, u);
		Assert.assertTrue(this.userService.delete(u.getId()));
	}

	private void assertMatch(byte[] oAuthData, User u) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		JsonNode jsonNode = mapper.readTree(new String(oAuthData));

		String userId = jsonNode.get("id").getTextValue();
		String firstName = jsonNode.get("first_name").getTextValue();
		String lastName = jsonNode.get("last_name").getTextValue();
		Assert.assertTrue(u.getId() > 0);
		Assert.assertEquals(userId, u.getUserId());
		Assert.assertEquals(firstName, u.getFirstName());
		Assert.assertEquals(lastName, u.getLastName());
	}

}
