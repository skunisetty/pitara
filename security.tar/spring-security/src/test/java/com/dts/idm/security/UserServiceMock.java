package com.dts.idm.security;

import com.dts.idm.dto.Status;
import com.dts.idm.dto.User;
import com.dts.idm.service.ServiceException;
import com.dts.idm.service.UserService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class UserServiceMock implements UserService {
	private static final Log log = LogFactory.getLog(UserServiceMock.class);
	private static int count =11345923;
	public static Collection<User> users;

	static {
		List<User> userList = new ArrayList<User>();

		for (int i = 1; i < 6; i++) {
			User u = new User();
			u.setId(Long.valueOf(1000 + i));
			u.setFirstName("firstName_" + i);
			u.setLastName("lastName_" + i);
			u.setPassword("password_" + i);
			u.setStatus(Status.ACTIVE);
			u.setTenantId(i + "");
			u.setUserId("netId_" + i);
			userList.add(u);
		}
		// users = userList.toArray(new User[userList.size()]);
		users = userList;
	}

	@Override
	public User authenticate(String usrId, String pwd) throws ServiceException {
		User u = this.findUserByUserId(usrId);
		if (u != null) {
			if (u.getPassword().equals(pwd)) {
				return u;
			}
			throw ServiceException.AUTHENTICATION_NEEDED;
		}
		throw ServiceException.UNKNOWN_RESOURCE;
	}

	@Override
	public void changePassword(Long userDBId, String oldPassword, String newPassword)
			throws ServiceException {
		User u = this.findById(userDBId);
		if (u != null) {
			u.setPassword(newPassword);
		} else {
			throw ServiceException.UNKNOWN_RESOURCE;
		}
	}

	@Override
	public void changePassword(String usersUserId, String oldPassword, String newPassword)
			throws ServiceException {
		User u = this.findUserByUserId(usersUserId);
		if (u != null) {
			u.setPassword(newPassword);
		} else {
			throw ServiceException.UNKNOWN_RESOURCE;
		}

	}

	@Override
	public User createUserWithPassword(User user, String pwd)
			throws ServiceException {
		return null;
	}

	@Override
	public User findUserByUserId(String userId) throws ServiceException {
		for (User u : users) {
			if (u.getUserId().equals(userId)) {
				return u;
			}
		}
		throw ServiceException.UNKNOWN_RESOURCE;
	}

	@Override
	public int updateUserStatus(Collection<Long> idList, Status newStatus)
			throws ServiceException {
		int updated =0;
		for (Long id : idList) {
			User u = this.findById(id);
			if (u != null) {
				u.setStatus(newStatus);
				++id;
			}			
		}
		return updated;
	}

	@Override
	public boolean delete(Long id) throws ServiceException {
		for (User u: users) {
			if (u.getId().equals(id)) {
				return users.remove(u);
			}
		}
		return false;
	}

	@Override
	public Collection<User> findAll() throws ServiceException {
		return users;
	}

	@Override
	public User findById(Long id) throws ServiceException {
		User u= getUserById(id);
		if (u==null) {
			throw ServiceException.UNKNOWN_RESOURCE;
		}
		return u;
	}

	@Override
	public User save(User model) throws ServiceException {
		if (null==model.getId()) {
			model.setId(Long.valueOf(++count));
		}
		users.add(model);
		return model;
	}

	@Override
	public Collection<User> search(User criteria) throws ServiceException {
		return null;
	}

	public static User getUserById(Long usrId) {
		for (User u : users) {
			if (u.getId().equals(usrId)) {
				return u;
			}
		}
		return null;
	}

	@Override
	public Collection<User> findUsersByStatus(Status status)
			throws ServiceException {
		List<User> l = new ArrayList<User>();
		for (User u: users) {
			if (u.getStatus().equals(status)) {
				l.add(u);
			}
		}
		return l;
	}
	
	public boolean delete(User u) {
		return users.remove(u);
	}

	@Override
	public Collection<User> findUsersLike(String like) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User findUserCredentials(String usrId) throws ServiceException {
		User found =null;
		for (User u: users){
			if (u.getUserId().equals(usrId)) {
				found = u;
				break;
			}
		}
		if (found==null) {
			log.info("No user found by usrId: " + usrId);
			throw ServiceException.UNKNOWN_RESOURCE;
		}
		return found;
	}
	

	@Override
	public Collection<String> checkAvailableIds(List<String> netIdList)
			throws ServiceException {
		for (User u: users) {
			netIdList.remove(u.getUserId());
		}
		return netIdList;
	}
	

	@Override
	public void resetPassword(Long userDBId, String newPassword)
			throws ServiceException {
		User u = this.findById(userDBId);
		if (u != null) {
			u.setPassword(newPassword);
		} else {
			throw ServiceException.UNKNOWN_RESOURCE;
		}
	}

	@Override
	public void resetPassword(String usersUserId, String newPassword)
			throws ServiceException {
		User u = this.findUserByUserId(usersUserId);
		if (u != null) {
			u.setPassword(newPassword);
		} else {
			throw ServiceException.UNKNOWN_RESOURCE;
		}
	}
}
