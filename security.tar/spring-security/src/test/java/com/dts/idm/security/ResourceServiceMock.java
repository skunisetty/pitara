package com.dts.idm.security;

import com.dts.idm.dto.AuthToken;
import com.dts.idm.dto.Resource;
import com.dts.idm.dto.UserResource;
import com.dts.idm.service.ResourceService;
import com.dts.idm.service.ServiceException;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class ResourceServiceMock implements ResourceService {
    private UnsupportedOperationException noe = new UnsupportedOperationException();
    static private int counter = 0;
    private Map<Long, UserResource> userIdResourceMap = new HashMap<>();
    private Map<Long, UserResource> resourceIdResourceMap = new HashMap<>();

    @Override
    public int delete(Collection<Integer> resourceIdList)
            throws ServiceException {
        return 0;
    }

    @Override
    public int deleteUserResource(Collection<UserResource> userResource)
            throws ServiceException {
        for (UserResource ur : userResource) {
            this.resourceIdResourceMap.remove(ur.getResource().getId());
            this.userIdResourceMap.remove(ur.getUser().getId());
        }
        return userResource.size();
    }

    @Override
    public Collection<Resource> findAll() throws ServiceException {
        throw noe;
    }

    @Override
    public Resource findById(int resourceId) throws ServiceException {
        throw noe;
    }

    @Override
    public Collection<Resource> findByName(String name) throws ServiceException {
        throw noe;
    }

    @Override
    public Collection<AuthToken> findUserAuthToken(Long userId)
            throws ServiceException {
        throw noe;
    }

    @Override
    public AuthToken findUserAuthToken(UserResource userResource)
            throws ServiceException {
        UserResource ur = this.resourceIdResourceMap.get(userResource.getResource().getId());
        if (ur == null) {
            throw ServiceException.UNKNOWN_RESOURCE;
        }
        AuthToken at = ur.getAuthToken();

        return at;
    }

    @Override
    public Collection<UserResource> findUserResource(Long userId)
            throws ServiceException {
        throw noe;
    }

    @Override
    public Collection<UserResource> findUserResource(UserResource userResource)
            throws ServiceException {
        throw noe;
    }

    @Override
    public AuthToken getConsumerToken(Integer resourceId)
            throws ServiceException {
        throw noe;
    }

    @Override
    public Resource save(Resource resource) throws ServiceException {
        throw noe;
    }

    @Override
    public UserResource saveUserResource(UserResource userResource)
            throws ServiceException {
        this.userIdResourceMap
                .put(userResource.getUser().getId(), userResource);
        userResource.setId(Long.valueOf(++counter));
        this.resourceIdResourceMap.put(userResource.getResource().getId(), userResource);
        return userResource;
    }

    @Override
    public void setConsumerToken(Integer resourceId, AuthToken authToken)
            throws ServiceException {
        throw noe;
    }

    @Override
    public AuthToken updateUserAuthToken(UserResource userResource)
            throws ServiceException {
        throw noe;
    }

    @Override
    public boolean delete(int id) throws ServiceException {
        throw noe;
    }

    @Override
    public Collection<Resource> search(Resource criteria)
            throws ServiceException {
        throw noe;
    }

    @Override
    public int deleteUserResources(Long usrId) throws ServiceException {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public int deleteUserResources(String usrNetId) throws ServiceException {
        // TODO Auto-generated method stub
        return 0;
    }

}
