package com.dts.idm.security.mock;

import com.dts.idm.dto.User;
import com.dts.idm.security.OAuthAuthenticationToken;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.HashMap;
import java.util.Map;

public class AuthenticationManagerMock implements AuthenticationManager {
	private Authentication authentication;
	
	private Map<String, String> users = new HashMap<String, String>();
	private boolean passwordCheck = true;
	public AuthenticationManagerMock() {
		users.put("bhola", "lala");
		users.put("goat", "lamb");
	}
	
	public Authentication getAuthentication() {
		return authentication;
	}
	
	public void togglePasswordCheck() {
		this.passwordCheck ^= true;
	}

	@Override
	public Authentication authenticate(Authentication authentication)
			throws AuthenticationException {
		if (authentication.isAuthenticated()) {
			return authentication;
		}
		OAuthAuthenticationToken token = (OAuthAuthenticationToken)authentication;
		String pwd = this.users.get(token.getPrincipal());
		if (this.passwordCheck && pwd==null) {
			throw new UsernameNotFoundException(String.valueOf(token.getPrincipal()));
		}
		if (this.passwordCheck && !pwd.equals(token.getCredentials())) {
			throw new BadCredentialsException(String.valueOf(token.getPrincipal()));
		}
		this.authentication = authentication;
		return authentication;
	}
	
	public void addUser(User user) {
		this.users.put(user.getUserId(), "pwd");
	}
	
	public void removeUser(String usrId) {
		this.users.remove(usrId);
	}

	public void clear() {
		this.authentication =null;
	}
}
