package com.dts.idm.auth;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: sanjeev
 * Time: 9:05 AM
 * To change this template use File | Settings | File Templates.
 */
public class PRNGUtilTest {
    private static final Log LOG = LogFactory.getLog(PRNGUtilTest.class);
    @Test
    public void generate() {
        int numIterations = 25;
        for (int i = 0; i < numIterations; i++) {
            // Grab our next random pseudorandom value. Log it to show that everything works.
            final byte[] value = PRNGUtil.next();
            if (LOG.isInfoEnabled()) {
                final String valueStr = Hex.encodeHexString(value);
                LOG.info(String.format("Iteration %d:  encrypted counter is %s", i, valueStr));
            }
        }
    }
}
