package com.dts.idm.security.web.filter;


import com.dts.common.StreamUtils;
import com.dts.idm.dto.User;
import com.dts.idm.security.AuthScheme;
import com.dts.idm.security.FacebookAuthHandler;
import com.dts.idm.security.OAuthAuthenticationToken;
import com.dts.idm.security.OAuthToken;
import com.dts.idm.security.mock.AuthenticationManagerMock;
import junit.framework.Assert;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.ProviderNotFoundException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.servlet.ServletException;
import java.io.IOException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:idm-security.xml",
		"classpath:spring-security-test.xml" })
public class SocialAuthenticationFilterTest {
	private static final Log log = LogFactory
			.getLog(SocialAuthenticationFilterTest.class);
	@Autowired
	private SocialAuthenticationFilter socialAuthenticationFilter;

	private AuthenticationManagerMock mockAuthManager = new AuthenticationManagerMock();

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private FacebookAuthHandler facebookAuthHandler;

	@Before
	public void setUp() {
		this.mockAuthManager.clear();
		this.socialAuthenticationFilter
				.setAuthenticationManager(this.mockAuthManager);
	}

	@Before
	public void tearDown() {
		this.socialAuthenticationFilter
				.setAuthenticationManager(this.authenticationManager);
	}

	@Test
	public void testAuthBasicMissingHeader() throws IOException,
			ServletException {
		AuthScheme authScheme = socialAuthenticationFilter.getAuthScheme();
		socialAuthenticationFilter.setAuthScheme(AuthScheme.BASIC);
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();

		try {
			this.socialAuthenticationFilter.attemptAuthentication(request,
					response);
			Assert.fail();
		} catch (AuthenticationException ae) {
			Assert.assertTrue(UsernameNotFoundException.class
                    .isAssignableFrom(ae.getClass()));
		}

		this.socialAuthenticationFilter.setAuthScheme(authScheme);
	}

	@Test
	public void testAuthBasicSuccess() throws IOException, ServletException {
		AuthScheme authScheme = socialAuthenticationFilter.getAuthScheme();
		socialAuthenticationFilter.setAuthScheme(AuthScheme.BASIC);
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		String usr = "bhola";
		String pwd = "lala";
		String encoded = Base64
				.encodeBase64String((usr + ":" + pwd).getBytes());
		request.addHeader("Authorization", "Basic " + encoded);
		Authentication auth = this.socialAuthenticationFilter
				.attemptAuthentication(request, response);
		Assert.assertNotNull(auth);
		Assert.assertSame(this.mockAuthManager.getAuthentication(), auth);
		OAuthAuthenticationToken token = (OAuthAuthenticationToken) auth;
		Assert.assertEquals(usr, token.getPrincipal());
		Assert.assertEquals(pwd, token.getCredentials());

		this.socialAuthenticationFilter.setAuthScheme(authScheme);
	}

	@Test
	public void testAuthBasicBadCredentials() throws IOException,
			ServletException {
		AuthScheme authScheme = socialAuthenticationFilter.getAuthScheme();
		socialAuthenticationFilter.setAuthScheme(AuthScheme.BASIC);
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		String usr = "bhola";
		String pwd = "lola";
		String encoded = Base64
				.encodeBase64String((usr + ":" + pwd).getBytes());
		request.addHeader("Authorization", "Basic " + encoded);
		try {
			this.socialAuthenticationFilter.attemptAuthentication(request,
					response);
			Assert.fail();
		} catch (AuthenticationException ae) {
			Assert.assertTrue(BadCredentialsException.class.isAssignableFrom(ae
                    .getClass()));
		}
		Assert.assertNull(this.mockAuthManager.getAuthentication());
		this.socialAuthenticationFilter.setAuthScheme(authScheme);
	}

	@Test
	public void testAuthFormMissingParameter() throws IOException,
			ServletException {
		AuthScheme authScheme = socialAuthenticationFilter.getAuthScheme();
		socialAuthenticationFilter.setAuthScheme(AuthScheme.FORM);
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();

		try {
			this.socialAuthenticationFilter.attemptAuthentication(request,
					response);
			Assert.fail();
		} catch (AuthenticationException ae) {
			Assert.assertTrue(UsernameNotFoundException.class
                    .isAssignableFrom(ae.getClass()));
		}

		this.socialAuthenticationFilter.setAuthScheme(authScheme);
	}

	@Test
	public void testAuthFormAuthSuccess() throws IOException, ServletException {
		AuthScheme authScheme = socialAuthenticationFilter.getAuthScheme();
		socialAuthenticationFilter.setAuthScheme(AuthScheme.FORM);
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		String usr = "bhola";
		String pwd = "lala";
		request.addParameter(
				SocialAuthenticationFilter.IDM_SECURITY_FORM_USERNAME_KEY, usr);
		request.addParameter(
				SocialAuthenticationFilter.IDM_SECURITY_FORM_PASSWORD_KEY, pwd);

		Authentication auth = this.socialAuthenticationFilter
				.attemptAuthentication(request, response);
		Assert.assertNotNull(auth);
		Assert.assertSame(this.mockAuthManager.getAuthentication(), auth);
		OAuthAuthenticationToken token = (OAuthAuthenticationToken) auth;
		Assert.assertEquals(usr, token.getPrincipal());
		Assert.assertEquals(pwd, token.getCredentials());

		this.socialAuthenticationFilter.setAuthScheme(authScheme);
	}

	@Test
	public void testAuthFormBadCredentials() throws IOException,
			ServletException {
		AuthScheme authScheme = socialAuthenticationFilter.getAuthScheme();
		socialAuthenticationFilter.setAuthScheme(AuthScheme.FORM);
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		String usr = "bhola";
		String pwd = "lola";
		request.addParameter(
				SocialAuthenticationFilter.IDM_SECURITY_FORM_USERNAME_KEY, usr);
		request.addParameter(
				SocialAuthenticationFilter.IDM_SECURITY_FORM_PASSWORD_KEY, pwd);

		try {
			this.socialAuthenticationFilter.attemptAuthentication(request,
					response);
			Assert.fail();
		} catch (AuthenticationException ae) {
			Assert.assertTrue(BadCredentialsException.class.isAssignableFrom(ae
                    .getClass()));
		}
		Assert.assertNull(this.mockAuthManager.getAuthentication());
		this.socialAuthenticationFilter.setAuthScheme(authScheme);
	}

	@Test
	public void testAuthFormUnknownUser() throws IOException, ServletException {
		AuthScheme authScheme = socialAuthenticationFilter.getAuthScheme();
		socialAuthenticationFilter.setAuthScheme(AuthScheme.FORM);
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		String usr = "bhila";
		String pwd = "lala";
		request.addParameter(
				SocialAuthenticationFilter.IDM_SECURITY_FORM_USERNAME_KEY, usr);
		request.addParameter(
				SocialAuthenticationFilter.IDM_SECURITY_FORM_PASSWORD_KEY, pwd);

		try {
			this.socialAuthenticationFilter.attemptAuthentication(request,
					response);
			Assert.fail();
		} catch (AuthenticationException ae) {
			Assert.assertTrue(UsernameNotFoundException.class
                    .isAssignableFrom(ae.getClass()));
		}
		Assert.assertNull(this.mockAuthManager.getAuthentication());
		this.socialAuthenticationFilter.setAuthScheme(authScheme);
	}

	@Test
	public void testFacebookAuthentication() throws Exception,
			AuthenticationException, ServletException {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		request.addHeader(
				SocialAuthenticationFilter.IDM_SECURITY_OAUTH_VERIFIED_KEY, 1);
		request.addHeader(
				SocialAuthenticationFilter.IDM_SECURITY_OAUTH_PROVIDER_ID,
				this.facebookAuthHandler.getProviderId());
		byte[] oAuthData = StreamUtils.loadContent("data/facebook.auth");

		// request.addParameter(
		// SocialAuthenticationFilter.IDM_SECURITY_OAUTH_DATA, new String(
		// oAuthData));
		request.setContent(oAuthData);

		User user = extractUser(oAuthData);
		try {
			mockAuthManager.addUser(user);
			this.mockAuthManager.togglePasswordCheck();
			OAuthAuthenticationToken authentication = (OAuthAuthenticationToken) this.socialAuthenticationFilter
					.attemptAuthentication(request, response);
			Assert.assertNotNull(authentication);
			OAuthToken authToken = authentication.getOAuthToken();
			Assert.assertNotNull(authToken);
			Assert.assertEquals(new String(oAuthData), new String(authToken
                    .getOAuthData()));
		} finally {
			this.mockAuthManager.togglePasswordCheck();
			if (user != null) {
				mockAuthManager.removeUser(user.getUserId());
			}
		}
	}

	private User extractUser(byte[] data) throws Exception {
		JsonNode jsonNode = new ObjectMapper().readTree(new String(data));
		if (log.isDebugEnabled()) {
			log.debug("processing jsonNode: " + jsonNode);
		}
		String userId = jsonNode.get("id").getTextValue();
		String firstName = jsonNode.get("first_name").getTextValue();
		String lastName = jsonNode.get("last_name").getTextValue();
		User user = new User();
		user.setUserId(userId);
		user.setFirstName(firstName);
		user.setLastName(lastName);
		if (log.isDebugEnabled()) {
			log.debug("creating userDetails for user: " + user);
		}
		return user;
	}

	@Test
	public void testMissingProviderAuthentication() throws IOException,
			ServletException {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		request.addHeader(
				SocialAuthenticationFilter.IDM_SECURITY_OAUTH_VERIFIED_KEY, 1);
		request.addHeader(
				SocialAuthenticationFilter.IDM_SECURITY_OAUTH_PROVIDER_ID,
				"");
		byte[] oAuthData = StreamUtils.loadContent("data/facebook.auth");

		// request.addParameter(
		// SocialAuthenticationFilter.IDM_SECURITY_OAUTH_DATA, new String(
		// oAuthData));
		request.setContent(oAuthData);
		try {
			this.socialAuthenticationFilter.attemptAuthentication(request,
					response);
		} catch (AuthenticationException e) {
			Assert.assertTrue(ProviderNotFoundException.class
                    .isAssignableFrom(e.getClass()));
		}
	}

	@Test
	public void testFormAuthenticationRequiredFalse() throws Exception,
			AuthenticationException, ServletException {
		AuthScheme authScheme = socialAuthenticationFilter.getAuthScheme();
		try {

			socialAuthenticationFilter.setAuthScheme(AuthScheme.FORM);

			MockHttpServletRequest request = new MockHttpServletRequest();
			request.setRequestURI("/not_j_idm_security_check");
			MockHttpServletResponse response = new MockHttpServletResponse();

			request.addHeader(
					SocialAuthenticationFilter.IDM_SECURITY_OAUTH_VERIFIED_KEY,
					1);
			request.addHeader(
					SocialAuthenticationFilter.IDM_SECURITY_OAUTH_PROVIDER_ID,
					this.facebookAuthHandler.getProviderId());
			byte[] oAuthData = StreamUtils.loadContent("data/facebook.auth");
			MockFilterChain chain = new MockFilterChain();
			request.setContent(oAuthData);
			this.socialAuthenticationFilter.doFilter(request, response, chain);
			Assert.assertNotNull(chain.getRequest());
			Assert.assertNotNull(chain.getResponse());
		} finally {
			socialAuthenticationFilter.setAuthScheme(authScheme);
		}
	}

	@Test
	public void testFormAuthenticationRequiredTrue() throws Exception,
			AuthenticationException, ServletException {
		AuthScheme authScheme = socialAuthenticationFilter.getAuthScheme();
		try {

			socialAuthenticationFilter.setAuthScheme(AuthScheme.FORM);

			MockHttpServletRequest request = new MockHttpServletRequest();
			request.setRequestURI("/j_spring_security_check");
			MockHttpServletResponse response = new MockHttpServletResponse();
			request.addHeader(
					SocialAuthenticationFilter.IDM_SECURITY_OAUTH_VERIFIED_KEY,
					1);
			request.addHeader(
					SocialAuthenticationFilter.IDM_SECURITY_OAUTH_PROVIDER_ID,
					this.facebookAuthHandler.getProviderId());
			byte[] oAuthData = StreamUtils.loadContent("data/facebook.auth");
			MockFilterChain chain = new MockFilterChain();
			request.setContent(oAuthData);
			this.socialAuthenticationFilter.doFilter(request, response, chain);

			Assert.assertNull(chain.getRequest());
			Assert.assertNull(chain.getResponse());
		} finally {
			socialAuthenticationFilter.setAuthScheme(authScheme);
		}
	}
}