package com.dts.idm.security;


import com.dts.idm.dto.User;
import com.dts.idm.service.ServiceException;
import com.dts.idm.service.UserService;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring-security.xml",  "classpath:spring-security-test.xml"})public class UserDetailsServiceTest {
	@Autowired
	private UserService userService;
	@Autowired
	private UserDetailsService userDetailService;

	@Before
	public void init() {
		Assert.assertNotNull(userService);
		Assert.assertNotNull(userDetailService);
	}

	@After
	public void tearDown() {
		((UserDetailsServiceImpl) this.userDetailService)
				.setCreateAccountIfAuthenticated(true);
	}

	@Test
	public void testLoadUserByUserNameNegative() {
		((UserDetailsServiceImpl) this.userDetailService)
				.setCreateAccountIfAuthenticated(false);
		try {
			this.userDetailService.loadUserByUsername("foo");
			Assert.fail("Exception should be thrown");
		} catch (UsernameNotFoundException e) {
		}
	}

	@Test
	public void testLoadUserByUserNameCreateIfAuthenticated() {
		((UserDetailsServiceImpl) this.userDetailService)
				.setCreateAccountIfAuthenticated(true);
		try {
			String userId = "foo@test.net";
			try {
				this.userService.findUserByUserId(userId);
				Assert.fail("ServiceException should be thrown");
			} catch (ServiceException e) {
			}
			UserDetails ud = this.userDetailService.loadUserByUsername(userId);
			Assert.assertNotNull(ud);
			Assert.assertEquals(userId, ud.getUsername());
			try {
				User u = this.userService.findUserByUserId(userId);
				Assert.assertEquals(userId, u.getUserId());
				Assert.assertEquals(true, ((UserServiceMock) this.userService).delete(u.getId()));
			} catch (ServiceException e) {
				Assert.fail("ServiceException should not be thrown");
			}
		} catch (UsernameNotFoundException e) {
			Assert.fail("Exception should not be thrown");
		}
	}

	@Test
	public void testLoadUserByUserName() {
		((UserDetailsServiceImpl) this.userDetailService)
				.setCreateAccountIfAuthenticated(false);

		String userId = "netId_1";
		UserDetails ud = this.userDetailService.loadUserByUsername(userId);
		Assert.assertNotNull(ud);
		Assert.assertEquals(userId, ud.getUsername());
	}
}
