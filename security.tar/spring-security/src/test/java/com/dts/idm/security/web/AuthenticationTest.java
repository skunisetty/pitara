package com.dts.idm.security.web;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
        "classpath:idm-security.xml",
        "classpath:spring-security-test.xml" })
public class AuthenticationTest {
	@Test
	public void testPositive() {
		
	}
}
