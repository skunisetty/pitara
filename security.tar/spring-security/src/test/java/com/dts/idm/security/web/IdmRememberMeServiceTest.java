package com.dts.idm.security.web;

import com.dts.idm.dto.Authorization;
import com.dts.idm.dto.User;
import com.dts.idm.security.OAuthAuthenticationToken;
import com.dts.idm.security.UserDetailsImpl;
import com.dts.idm.service.ServiceException;
import com.dts.idm.service.TicketService;
import com.dts.idm.service.UserService;
import junit.framework.Assert;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.authentication.RememberMeServices;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.inject.Inject;
import javax.servlet.http.Cookie;
import java.util.Collection;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:idm-security.xml",
		"classpath:spring-security-test.xml" })
public class IdmRememberMeServiceTest {
    private static final Log log = LogFactory.getLog(IdmRememberMeServiceTest.class);
	@Autowired
	private RememberMeServices rememberMeServices;
	private IdmRememberMeService idmRememberMe;

	@Inject
	private TicketService ticketService;

	@Inject
	private UserService userService;

	@Before
	public void init() {
		idmRememberMe = (IdmRememberMeService) rememberMeServices;
		Assert.assertNotNull(this.rememberMeServices);
		Assert.assertNotNull(this.idmRememberMe);
	}

	@Test
	public void testAutoLoginNoCookie() {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		Assert.assertNull(this.rememberMeServices.autoLogin(request, response));
	}

	@Test
	public void testSuccessfulLogin() throws ServiceException {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		request.addParameter(IdmRememberMeService.IDM_REMEMBER_ME, "1");

		Assert.assertNull(this.rememberMeServices.autoLogin(request, response));
		User user = userService.findUserByUserId("netId_3");
		Assert.assertNotNull(user);
		OAuthAuthenticationToken auth = new OAuthAuthenticationToken(
				new UserDetailsImpl(user));
		this.rememberMeServices.loginSuccess(request, response, auth);
		Cookie[] cookies = response.getCookies();
		Assert.assertTrue(cookies.length == 1);
		Cookie ticket = cookies[0];
		Assert.assertNotNull(ticket.getValue());
		Assert.assertEquals(IdmRememberMeService.IDM_TICKET, ticket.getName());
		if (StringUtils.isNotBlank(idmRememberMe.getDefaultDomain())) {
			Assert.assertEquals(idmRememberMe.getDefaultDomain(), ticket
					.getDomain());
		}
		Assert.assertEquals(idmRememberMe.getDurationInDays() * 24 * 60 * 60,
				ticket.getMaxAge());
		String st = ticket.getValue();
		Authorization authorization = this.ticketService.validate(st);
        log.debug("the auth sent by ticket service: " + authorization);
		Assert.assertEquals(user.getUserId(), authorization.getPrincipal());
		Assert.assertEquals((Long) user.getId(), (Long) authorization
				.getUserId());
	}

	@Test
	public void testSuccessfulLoginRememberMeParamFalse()
			throws ServiceException {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.setParameter(IdmRememberMeService.IDM_REMEMBER_ME, "0");
		MockHttpServletResponse response = new MockHttpServletResponse();

		Assert.assertNull(this.rememberMeServices.autoLogin(request, response));
		User user = userService.findUserByUserId("netId_3");
		Assert.assertNotNull(user);
		OAuthAuthenticationToken auth = new OAuthAuthenticationToken(
				new UserDetailsImpl(user));
		this.rememberMeServices.loginSuccess(request, response, auth);
		Cookie[] cookies = response.getCookies();
		Assert.assertTrue(cookies.length == 0);
	}

	@Test
	public void testRememberMeWithRememberMeEnabled() throws ServiceException {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		Assert.assertNull(this.rememberMeServices.autoLogin(request, response));
		User user = userService.findUserByUserId("netId_2");
		Assert.assertNotNull(user);

		OAuthAuthenticationToken auth = new OAuthAuthenticationToken(
				new UserDetailsImpl(user));
		this.rememberMeServices.loginSuccess(request, response, auth);
		Cookie[] cookies = response.getCookies();
		Assert.assertTrue(cookies.length == 1);
		Cookie ticket = cookies[0];
		Assert.assertNotNull(ticket.getValue());
		Assert.assertEquals(IdmRememberMeService.IDM_TICKET, ticket.getName());
		if (StringUtils.isNotBlank(idmRememberMe.getDefaultDomain())) {
			Assert.assertEquals(idmRememberMe.getDefaultDomain(), ticket
					.getDomain());
		}
		
		Assert.assertEquals(idmRememberMe.getDurationInDays() * 24 * 60 * 60,
				ticket.getMaxAge());
		String st = ticket.getValue();
		Authorization authorization = this.ticketService.validate(st);
		Assert.assertEquals(user.getUserId(), authorization.getPrincipal());
		Assert.assertEquals((Long) user.getId(), (Long) authorization
				.getUserId());

		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
		request.setCookies(ticket);

		Authentication authentication = this.rememberMeServices.autoLogin(
				request, response);
		Assert.assertNotNull(authentication);
		Assert.assertTrue(authentication.isAuthenticated());
		Assert.assertEquals(((UserDetailsImpl) auth.getPrincipal())
				.getUsername(), ((UserDetailsImpl) authentication
				.getPrincipal()).getUsername());

		Assert.assertEquals(((UserDetailsImpl) auth.getPrincipal())
				.getAuthorities().size(), ((UserDetailsImpl) authentication
				.getPrincipal()).getAuthorities().size());
	}

	@Test
	public void testRememberMeWithRememberMeParam() throws ServiceException {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		Assert.assertNull(this.rememberMeServices.autoLogin(request, response));
		User user = userService.findUserByUserId("netId_2");
		Assert.assertNotNull(user);
		request.setParameter(IdmRememberMeService.IDM_REMEMBER_ME, "1");
		OAuthAuthenticationToken auth = new OAuthAuthenticationToken(
				new UserDetailsImpl(user));
		this.rememberMeServices.loginSuccess(request, response, auth);
		Cookie[] cookies = response.getCookies();
		Assert.assertTrue(cookies.length == 1);
		Cookie ticket = cookies[0];
		Assert.assertNotNull(ticket.getValue());
		Assert.assertEquals(IdmRememberMeService.IDM_TICKET, ticket.getName());
		if (StringUtils.isNotBlank(idmRememberMe.getDefaultDomain())) {
			Assert.assertEquals(idmRememberMe.getDefaultDomain(), ticket
					.getDomain());
		}
		Assert.assertEquals(idmRememberMe.getDurationInDays() * 24 * 60 * 60,
				ticket.getMaxAge());
		String st = ticket.getValue();
		Authorization authorization = this.ticketService.validate(st);
		Assert.assertEquals(user.getUserId(), authorization.getPrincipal());
		Assert.assertEquals((Long) user.getId(), (Long) authorization
				.getUserId());

		request = new MockHttpServletRequest();
		response = new MockHttpServletResponse();
		request.setCookies(ticket);

		Authentication authentication = this.rememberMeServices.autoLogin(
				request, response);
		Assert.assertNotNull(authentication);
		Assert.assertTrue(authentication.isAuthenticated());
		Assert.assertEquals(((UserDetailsImpl) auth.getPrincipal())
				.getUsername(), ((UserDetailsImpl) authentication
				.getPrincipal()).getUsername());

		Assert.assertEquals(((UserDetailsImpl) auth.getPrincipal())
				.getAuthorities().size(), ((UserDetailsImpl) authentication
				.getPrincipal()).getAuthorities().size());
	}

	@Test
	public void testSuccessfulLoginUnsupportedAuthToken()
			throws ServiceException {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		Assert.assertNull(this.rememberMeServices.autoLogin(request, response));
		User user = userService.findUserByUserId("netId_3");
		Assert.assertNotNull(user);

		Authentication auth = new AuthenticationTokenMock();
		this.rememberMeServices.loginSuccess(request, response, auth);
		Cookie[] cookies = response.getCookies();
		Assert.assertTrue(cookies == null || cookies.length == 0);
	}

	@Test
	public void testDomainNameInQueryParam() throws ServiceException {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		Assert.assertNull(this.rememberMeServices.autoLogin(request, response));
		String testDomain = ".test.mot.com";
		request.addParameter(IdmRememberMeService.APP_DOMAIN, testDomain);
		request.setParameter(IdmRememberMeService.IDM_REMEMBER_ME, "1");
		User user = userService.findUserByUserId("netId_3");
		Assert.assertNotNull(user);
		OAuthAuthenticationToken auth = new OAuthAuthenticationToken(
				new UserDetailsImpl(user));
		this.rememberMeServices.loginSuccess(request, response, auth);
		Cookie[] cookies = response.getCookies();
		Assert.assertTrue(cookies.length == 1);
		Cookie ticket = cookies[0];
		Assert.assertNotNull(ticket.getValue());
		Assert.assertEquals(IdmRememberMeService.IDM_TICKET, ticket.getName());
		Assert.assertEquals(testDomain, ticket.getDomain());
		Assert.assertEquals(idmRememberMe.getDurationInDays() * 24 * 60 * 60,
				ticket.getMaxAge());
		String st = ticket.getValue();
		Authorization authorization = this.ticketService.validate(st);
		Assert.assertEquals(user.getUserId(), authorization.getPrincipal());
		Assert.assertEquals((Long) user.getId(), (Long) authorization
				.getUserId());
	}

	@Test
	public void testDomainNameInHeader() throws ServiceException {
		MockHttpServletRequest request = new MockHttpServletRequest();
		MockHttpServletResponse response = new MockHttpServletResponse();
		Assert.assertNull(this.rememberMeServices.autoLogin(request, response));
		String testDomain = ".test.mot.com";
		request.addHeader(IdmRememberMeService.APP_DOMAIN, testDomain);
		request.setParameter(IdmRememberMeService.IDM_REMEMBER_ME, "1");
		User user = userService.findUserByUserId("netId_3");
		Assert.assertNotNull(user);
		OAuthAuthenticationToken auth = new OAuthAuthenticationToken(
				new UserDetailsImpl(user));
		this.rememberMeServices.loginSuccess(request, response, auth);
		Cookie[] cookies = response.getCookies();
		Assert.assertTrue(cookies.length == 1);
		Cookie ticket = cookies[0];
		Assert.assertNotNull(ticket.getValue());
		Assert.assertEquals(IdmRememberMeService.IDM_TICKET, ticket.getName());
		Assert.assertEquals(testDomain, ticket.getDomain());
		Assert.assertEquals(idmRememberMe.getDurationInDays() * 24 * 60 * 60,
				ticket.getMaxAge());
		String st = ticket.getValue();
		Authorization authorization = this.ticketService.validate(st);
		Assert.assertEquals(user.getUserId(), authorization.getPrincipal());
		Assert.assertEquals((Long) user.getId(), (Long) authorization
				.getUserId());
	}
}

class AuthenticationTokenMock implements Authentication {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public Collection<GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getCredentials() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object getPrincipal() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isAuthenticated() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setAuthenticated(boolean isAuthenticated)
			throws IllegalArgumentException {
		// TODO Auto-generated method stub

	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
