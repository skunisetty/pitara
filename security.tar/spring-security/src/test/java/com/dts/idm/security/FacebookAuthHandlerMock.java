package com.dts.idm.security;

/**
 * Created by IntelliJ IDEA.
 * User: sanjeev
 * Time: 8:29 AM
 * To change this template use File | Settings | File Templates.
 */
public class FacebookAuthHandlerMock extends FacebookAuthHandler {
    protected boolean verifyAuthToken(String token, String uid, String fn, String ln) {
        return true;
    }
}
