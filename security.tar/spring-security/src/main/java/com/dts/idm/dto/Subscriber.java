package com.dts.idm.dto;

import java.util.Date;

public class Subscriber {
	private Date memberSince;

    public Date getMemberSince() {
        return memberSince;
    }

    public void setMemberSince(Date memberSince) {
        this.memberSince = memberSince;
    }
}
