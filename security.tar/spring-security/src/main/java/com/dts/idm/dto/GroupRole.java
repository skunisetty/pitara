package com.dts.idm.dto;

import java.util.Date;

public class GroupRole {
	private static final long serialVersionUID = 1L;
	private Group group = new Group();
	private Role role = new Role();
	
	private Date createdAt = new Date();
	
	public GroupRole() {
	}
	
	public GroupRole(int groupId, int roleId) {
		this.setGroupId(groupId);
		this.setRoleId(roleId);
	}
	
	public Integer getGroupId() {
		return this.group.getId();
	}
	
	public void setGroupId(int groupId) {
		this.group.setId(groupId);
	}
	
	public Integer getRoleId() {
		return this.role.getId();
	}
	
	public void setRoleId(int roleId) {
		this.role.setId(roleId);
	}

    public Group getGroup() {
        return group;
    }

    public void setGroup(Group group) {
        this.group = group;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}
