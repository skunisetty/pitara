package com.dts.idm.security;

import com.dts.idm.dto.Status;
import com.dts.idm.dto.User;
import com.dts.idm.service.ServiceException;
import com.dts.idm.service.UserService;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.util.Assert;

abstract public class AbstractOAuthHandler implements OAuthHandler, InitializingBean {
	private static final Log log = LogFactory
			.getLog(AbstractOAuthHandler.class);
	private String providerId;
	private UserService userService;
	private boolean createAccountIfAuthenticated;

	@Override
	public String getProviderId() {
		return this.providerId;
	}

	@Override
	abstract public UserDetails retrieveUser(OAuthToken token)
			throws AuthenticationException;

	protected UserDetails createUserDetails(User user)
			throws AuthenticationException {
		UserDetails ud =null;
		try {
			User found = this.userService.findUserByUserId(user.getUserId());
			if (found==null) {
				log.info("No user found by userId: " + user.getUserId());
			}
			else {
				ud = new UserDetailsImpl(found);
			}
		} catch (ServiceException e) {
			if (e.equals(ServiceException.UNKNOWN_RESOURCE)) {
				log.info("No user found by userId: " + user.getUserId());
			}
		}
		if (ud ==null) {
			ud= createUserOrDie(user);
		}
		return ud;
	}

	private UserDetails createUserOrDie(User user) throws AuthenticationException {
		if (this.createAccountIfAuthenticated) {
			log.info(String.format(
					"No user found by userId <%s> will be created!",
					user.getUserId()));
			try {
				user.setStatus(Status.ACTIVE);
				if (StringUtils.isBlank(user.getPassword())) {
					user.setPassword(System.nanoTime()+Math.random()+"");
				}
				
				user = this.userService.save(user);
				if (log.isDebugEnabled()) {
					log.debug(String.format(
							"Created a new user for UserId <%s>: %s",
							user.getUserId(), user));
				}
				return new UserDetailsImpl(user);
			} catch (ServiceException e1) {
				String msg = String
						.format(
								"Error creating user by userId <%s>. Details: %s",
								user.getUserId(), e1.getMessage());
				log.warn(msg, e1);
				throw new UsernameNotFoundException(msg);
			}
		}
		throw new UsernameNotFoundException("No User found userId "
				+ user.getUserId());		
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public boolean isCreateAccountIfAuthenticated() {
		return createAccountIfAuthenticated;
	}

	public void setCreateAccountIfAuthenticated(
			boolean createAccountIfAuthenticated) {
		this.createAccountIfAuthenticated = createAccountIfAuthenticated;
	}

	public void setProviderId(String providerId) {
		this.providerId = providerId;
	}
	
	@Override
	public void afterPropertiesSet() throws Exception {
		Assert.notNull(this.providerId, "providerId not set");
		Assert.notNull(this.userService, "userService not set");
	}
}
