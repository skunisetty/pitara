package com.dts.idm.dto;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: sanjeev
 * Time: 8:06 AM
 * To change this template use File | Settings | File Templates.
 */
public interface IUser {
    void setId(Long id);

    String getTenantId();

    void setTenantId(String tenantId);

    String getStatusCode();

    void setStatusCode(String code);

    String getUserId();

    void setUserId(String userId);

    String getFirstName();

    void setFirstName(String firstName);

    String getLastName();

    void setLastName(String lastName);

    Integer getSubscriberId();

    void setSubscriberId(Integer subscriberId);

    Date getCreatedAt();

    void setCreatedAt(Date createdAt);

    String getPassword();

    void setPassword(String password);
}
