package com.dts.idm.security.web;

import com.dts.idm.dto.User;
import com.dts.idm.security.OAuthAuthenticationToken;
import com.dts.idm.security.UserDetailsImpl;
import com.dts.idm.service.ServiceException;
import com.dts.idm.service.ServiceTicket;
import com.dts.idm.service.TicketService;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.RememberMeServices;
import org.springframework.security.web.authentication.logout.LogoutHandler;

import javax.inject.Inject;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class IdmRememberMeService implements RememberMeServices, LogoutHandler {
    static final String APP_DOMAIN = "app_domain";
    static final String IDM_TICKET = "_st";
    static final String IDM_REMEMBER_ME = "idm_remember";

    private static final Log log = LogFactory
            .getLog(IdmRememberMeService.class);
    private static final String XFF = "X-Forwarded-For";
    private static final String UNKNOWN = "";
    @Inject
    private TicketService ticketService;

    private int durationInDays;
    private String defaultDomain;
    private boolean rememberMeEnabled;

    @Override
    public Authentication autoLogin(HttpServletRequest request,
                                    HttpServletResponse response) {
        log.debug("trying autologin...");
        Cookie[] cookies = request.getCookies();
        if (cookies == null) {
            log.info("No serviceToken cookie");
            return null;
        }
        ServiceTicket st = this.extractServiceTicket(request);

        if (st != null) {
            try {
                User user = this.ticketService.extractUserInfo(st
                        .getValue());
                if (user==null) {
                	log.debug("invalid ticket!!!");
                	return null;
                }
                log
                        .debug("Extracted user from ticker: "
                                + user.getUserId());
                return new OAuthAuthenticationToken(new UserDetailsImpl(
                        user));
            } catch (ServiceException e) {
                log.info("Error validating service cookie", e);
            }
        }

        log.debug("autologin failed!");
        return null;
    }

    @Override
    public void loginFail(HttpServletRequest request,
                          HttpServletResponse response) {
        this.invalidateTicket(request);
        response.addCookie(new Cookie(IDM_TICKET, null));
    }

    @Override
    public void loginSuccess(HttpServletRequest request,
                             HttpServletResponse response, Authentication authentication) {
        log.debug("login success for: " + authentication);

        if (!this.shouldRemember(request)) {
            return;
        }

        log.debug("remember me for: " + authentication);

        if (UsernamePasswordAuthenticationToken.class
                .isAssignableFrom(authentication.getClass())) {
            User user = ((UserDetailsImpl) ((OAuthAuthenticationToken) authentication)
                    .getPrincipal()).getUser();
            try {
                int expiresInMin = this.durationInDays * 24 * 60;
                String ticket = this.ticketService.createServiceToken(user,
                        expiresInMin);
                Cookie serviceCookie = new Cookie(IDM_TICKET, ticket);
                serviceCookie.setMaxAge(expiresInMin*60);
                String domain = getDomain(request);
                if (StringUtils.isNotBlank(domain)) {
                    serviceCookie.setDomain(domain);
                }

                response.addCookie(serviceCookie);
                log.debug("created remember me for: " + authentication);

            } catch (ServiceException e) {
                log.warn("Error creating cookie _st for user: "
                        + user.getUserId(), e);
            }
        }
    }

    private boolean shouldRemember(HttpServletRequest request) {
        String rememberMeHeader = request.getParameter(IDM_REMEMBER_ME);
        log.debug("rememberMe header value: " + rememberMeHeader);

        if (StringUtils.isBlank(rememberMeHeader)) {
            return this.rememberMeEnabled;
        }
        try {
            if (Integer.parseInt(rememberMeHeader) != 1) {
                return false;
            }
        } catch (NumberFormatException nfe) {
        }
        return rememberMeEnabled;
    }

    public void setDurationInDays(int durationInDays) {
        this.durationInDays = durationInDays;
    }

    public String getDefaultDomain() {
        return this.defaultDomain;
    }

    public void setDefaultDomain(String domain) {
        this.defaultDomain = domain;
    }

    public int getDurationInDays() {
        return this.durationInDays;
    }

    public void setRememberMeEnabled(boolean rememberMeEnabled) {
        this.rememberMeEnabled = rememberMeEnabled;
    }

    @Override
    public void logout(HttpServletRequest request,
                       HttpServletResponse response, Authentication authentication) {
        invalidateTicket(request);
        response.addCookie(new Cookie(IDM_TICKET, null));
    }

    private void invalidateTicket(HttpServletRequest request) {
        ServiceTicket st = this.extractServiceTicket(request);
        if (st != null) {
           try {
               this.ticketService.invalidate(st.getValue());
           }
           catch (ServiceException se) {}
        }
    }

    private String getDomain(HttpServletRequest request) {
        String appDomain = request.getParameter(APP_DOMAIN);
        if (StringUtils.isBlank(appDomain)) {
            appDomain = request.getHeader(APP_DOMAIN);
            if (StringUtils.isBlank(appDomain)) {
                appDomain = this.defaultDomain;
            }
        }
        return appDomain;
    }

    private String extractClient(HttpServletRequest request) {
        String client = UNKNOWN;

        client = request.getHeader(XFF);
        if (client == null) {
            client = request.getHeader(XFF.toLowerCase());
            if (client == null) {
                client = request.getHeader(XFF.toUpperCase());
            }
        }
        if (client != null) {
            String[] parts = client.split(",");
            client = parts[0];
        } else {
            client = request.getRemoteAddr();
        }
        log.info("the requesting client: " + client);
        return client;
    }

    private ServiceTicket extractServiceTicket(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies == null) {
            log.info("No serviceToken cookie");
            return null;
        }
        for (Cookie c : cookies) {
            if (log.isDebugEnabled()) {
                log.debug("cookie: " + c);
            }
            if (c.getName().equals(IDM_TICKET)) {
                log.debug("_st cookie found: " + c.getValue());
            }
            ServiceTicket st = new ServiceTicket(c.getValue());
            st.setClient(this.extractClient(request));
            return st;
        }
        return null;
    }
}
