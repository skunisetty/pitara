package com.dts.idm.service;

public interface IdmSecurityContextHolder {
	Long getUserId();
}