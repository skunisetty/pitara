package com.dts.idm.service;

public interface TicketInvalidationListener {
    void invalidated(String ticket);
}
