package com.dts.idm.security;

public enum AuthScheme {
	BASIC, FORM
}
