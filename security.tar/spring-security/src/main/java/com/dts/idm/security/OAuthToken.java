package com.dts.idm.security;


import com.dts.idm.dto.AuthToken;

public class OAuthToken extends AuthToken {
	private static final long serialVersionUID = 1L;
	private String serviceProviderId;
	private byte[] oAuthData;
	
	public OAuthToken() {
	}
	
	public OAuthToken(String serviceProviderId) {
		this.serviceProviderId = serviceProviderId;
	}

    public String getServiceProviderId() {
        return serviceProviderId;
    }

    public void setServiceProviderId(String serviceProviderId) {
        this.serviceProviderId = serviceProviderId;
    }

    public byte[] getOAuthData() {
        return oAuthData;
    }

    public void setOAuthData(byte[] oAuthData) {
        this.oAuthData = oAuthData;
    }
}
