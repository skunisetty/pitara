package com.dts.idm.dto;


public class Tenant {
	private static final long serialVersionUID = 1L;

	private String name;
	private String description;
	private String adminEmail;
	private String domainName;
	private String token;
	private String secret;
	private String ticket;
    private String id;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAdminEmail() {
        return adminEmail;
    }

    public void setAdminEmail(String adminEmail) {
        this.adminEmail = adminEmail;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Long createdAt) {
        this.createdAt = createdAt;
    }

    public Long getModifiedAt() {
        return modifiedAt;
    }

    public void setModifiedAt(Long modifiedAt) {
        this.modifiedAt = modifiedAt;
    }

    public String getUpdateComments() {
        return updateComments;
    }

    public void setUpdateComments(String updateComments) {
        this.updateComments = updateComments;
    }

    public String getAdminPhoneNumber() {
        return adminPhoneNumber;
    }

    public void setAdminPhoneNumber(String adminPhoneNumber) {
        this.adminPhoneNumber = adminPhoneNumber;
    }

    public String getAdminSecEmail() {
        return adminSecEmail;
    }

    public void setAdminSecEmail(String adminSecEmail) {
        this.adminSecEmail = adminSecEmail;
    }

    public String getAdminSecPhoneNumber() {
        return adminSecPhoneNumber;
    }

    public void setAdminSecPhoneNumber(String adminSecPhoneNumber) {
        this.adminSecPhoneNumber = adminSecPhoneNumber;
    }

    public String getCallbackUrl() {
        return callbackUrl;
    }

    public void setCallbackUrl(String callbackUrl) {
        this.callbackUrl = callbackUrl;
    }

    private Status status;
	private Long   createdAt;
	private Long   modifiedAt;
    private String updateComments;	
	private String adminPhoneNumber;
	private String adminSecEmail;
	private String adminSecPhoneNumber;
	private String callbackUrl;
	
	public Tenant() {
	}

    public Tenant(String id) {
        this.setId(id);
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }
}
