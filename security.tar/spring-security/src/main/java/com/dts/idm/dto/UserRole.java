package com.dts.idm.dto;


import java.util.Date;

public class UserRole {
	private static final long serialVersionUID = 1L;
	private User user = new User();
	private Role role = new Role();
	private Date createdAt = new Date();

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}
