package com.dts.idm.dto;

import java.io.Serializable;
import java.util.Date;

public class AuthToken implements Serializable {
	private static final long serialVersionUID = 1L;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public int getResourceId() {
        return resourceId;
    }

    public void setResourceId(int resourceId) {
        this.resourceId = resourceId;
    }

    public String getPrincipal() {
        return principal;
    }

    public void setPrincipal(String principal) {
        this.principal = principal;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public Date getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(Date validFrom) {
        this.validFrom = validFrom;
    }

    public Date getValidTill() {
        return validTill;
    }

    public void setValidTill(Date validTill) {
        this.validTill = validTill;
    }

    private Long userId;
	private int resourceId;
	private String principal;
	private String token;
	private String secret;
	private Date validFrom;
	private Date validTill;
	
	public AuthToken() {
	}
	
	public AuthToken(String token, String secret) {
		this.token = token;
		this.secret = secret;
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("AuthToken[token=").append(this.token).append(", secret=").append(
				this.secret).append("]");
		return sb.toString();
	}
}
