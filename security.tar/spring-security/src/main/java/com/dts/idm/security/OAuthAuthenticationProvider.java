package com.dts.idm.security;

import com.dts.idm.auth.AuthUtil;
import com.dts.idm.dto.User;
import com.dts.idm.service.ServiceException;
import com.dts.idm.service.UserService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderNotFoundException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.util.Assert;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OAuthAuthenticationProvider implements AuthenticationProvider,
        InitializingBean {
    private static final Log log = LogFactory
            .getLog(OAuthAuthenticationProvider.class);

    public static final String FACEBOOK = "facebook";

    private Map<String, OAuthHandler> oAuthHandlers = new HashMap<String, OAuthHandler>();
    private UserService userService;

    @Override
    public Authentication authenticate(Authentication authentication)
            throws AuthenticationException {
        log.debug("handling auth ..." + authentication);
        if (authentication.isAuthenticated()) {
            return authentication;
        }
        if (!supports(authentication.getClass())) {
            return null;
        }

        if (OAuthAuthenticationToken.class.isAssignableFrom(authentication.getClass())) {
            OAuthAuthenticationToken oAuthToken = (OAuthAuthenticationToken) authentication;
            OAuthToken at = oAuthToken.getOAuthToken();
            if (at != null) {
                UserDetails ud = retrievUserDetails(at);
                oAuthToken = new OAuthAuthenticationToken(ud);
                return oAuthToken;
            }
        }

        return authenticate((UsernamePasswordAuthenticationToken) authentication);
    }

    private Authentication authenticate(UsernamePasswordAuthenticationToken token) {
        String netId = String.valueOf(token.getPrincipal());
        String credentials = String.valueOf(token.getCredentials());

        log.debug("fetching userPasswordToken for: principal " + netId);
        String password = String.valueOf(credentials);

        try {

            User user = userService.authenticate(netId, AuthUtil.hashPassword(netId, password));

            if (user != null) {
                user.setPassword(null);
                UserDetails ud = new UserDetailsImpl(user);
                return new OAuthAuthenticationToken(ud);
            }
        } catch (ServiceException se) {
            if (!se.getErrorCodes().contains(ServiceException.UNKNOWN_RESOURCE)) {
                log.warn("exception while authenticating user: " + netId + ". "
                        + se.getMessage());
            } else {
                log.debug("No user found by netId: " + netId);
            }
        } catch (Exception e) {
            log.warn("exception while hashing password for: " + netId + ". "
                    + e.getMessage());
        }
        throw new UsernameNotFoundException(netId);
    }

    private UserDetails retrievUserDetails(OAuthToken token) {
        log.debug("retrieving user details for: " + token);

        OAuthHandler handler = this.oAuthHandlers.get(token
                .getServiceProviderId());
        if (handler == null) {
            throw new ProviderNotFoundException(token.getServiceProviderId());
        }
        return handler.retrieveUser(token);
    }

    @Override
    public boolean supports(Class<? extends Object> authentication) {
        if (UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication)) {
            log.debug("supports : " + authentication);
            return true;
        }

        log.debug("does not support: " + authentication);
        return false;
    }

    protected Authentication createSuccessfulAuthentication(
            UserDetails userDetails, OAuthAuthenticationToken auth) {
        log.debug("creating succesfull auth for: " + auth);

        OAuthToken at = new OAuthToken();
        at.setPrincipal(userDetails.getUsername());
        at.setToken(userDetails.getUsername());
        Collection authorities = userDetails.getAuthorities();
        return new OAuthAuthenticationToken(userDetails, at, authorities);
    }

    public void setOAuthHandlers(List<OAuthHandler> oauthHandlers) {
        for (OAuthHandler h : oauthHandlers) {
            this.oAuthHandlers.put(h.getProviderId(), h);
        }
    }

    public void setUserService(UserService userService) {
        this.userService = userService;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Assert.notEmpty(this.oAuthHandlers,
                "There should atleast one oAuthHandler set!!!");

        Assert.notNull(this.userService, "userService not set!!!");

    }

    public void setoAuthHandlers(List<OAuthHandler> oAuthHandlers) {
        for (OAuthHandler h: oAuthHandlers) {
            this.oAuthHandlers.put(h.getProviderId(),h);
        }
    }
}
