package com.dts.idm.dto;

import java.util.Date;

public class User implements IUser {
	private static final long serialVersionUID = 1L;
    private Long id;
	private String userId;
	private String firstName;
	private String lastName;
	private Integer subscriberId;
	private Status status = Status.PENDING;
    private String tenantId;

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    private Date createdAt;
	private String password;

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String getTenantId() {
        return null;
    }

    @Override
    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    @Override
    public String getStatusCode() {
		return this.status.getCode();
	}

	@Override
    public void setStatusCode(String code) {
		this.status = Status.lookupByCode(code);
	}

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("User[id=").append(this.getId()).append(", userId=").append(
                this.getUserId()).append("]");
        return sb.toString();
    }

    @Override
    public String getUserId() {
        return userId;
    }

    @Override
    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Override
    public String getFirstName() {
        return firstName;
    }

    @Override
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Override
    public String getLastName() {
        return lastName;
    }

    @Override
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public Integer getSubscriberId() {
        return subscriberId;
    }

    @Override
    public void setSubscriberId(Integer subscriberId) {
        this.subscriberId = subscriberId;
    }

    @Override
    public Date getCreatedAt() {
        return createdAt;
    }

    @Override
    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public void setPassword(String password) {
        this.password = password;
    }

    public Long getId() {
        return id;
    }
}
