package com.dts.idm.security;

import com.dts.idm.dto.User;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class FacebookAuthHandler extends AbstractOAuthHandler {
	private static final Log log = LogFactory.getLog(FacebookAuthHandler.class);
	private ObjectMapper mapper = new ObjectMapper();
	private String profileUrl;

	@Override
	public UserDetails retrieveUser(OAuthToken token) {
		byte[] data = token.getOAuthData();
		try {
			JsonNode jsonNode = mapper.readTree(new String(data));
			if (log.isDebugEnabled()) {
				log.debug("processing jsonNode: " + jsonNode);
			}
			String userId = jsonNode.get("id").getTextValue();
			String firstName = jsonNode.get("first_name").getTextValue();
			String lastName = jsonNode.get("last_name").getTextValue();
			log.debug("token, userId, firstName, lastName: " + token.getToken() + " " + userId + " " + firstName + " " + lastName);
			if (!verifyAuthToken(token.getToken(), userId, firstName, lastName)) {
				throw new UsernameNotFoundException("unable to validate FB user");
			}
			User user = new User();
			user.setUserId(userId);
			user.setFirstName(firstName);
			user.setLastName(lastName);
			if (log.isDebugEnabled()) {
				log.debug("creating userDetails for user: " + user);
			}
			return this.createUserDetails(user);
		} catch (Exception e) {
			throw new UsernameNotFoundException(e.getMessage());
		}
	}
	
	public void setProfileUrl(String profileUrl) {
		this.profileUrl = profileUrl;
		//log.debug("Facebook profile url set to : " + profileUrl);
	}

	private String fetchProfileData(String token) {
		try {
			String urlStr = profileUrl + URLEncoder.encode(token, "UTF-8");
			URL url = new URL(urlStr);
			URLConnection conn = url.openConnection();
			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			StringBuffer buffer = new StringBuffer();
			while ((line = br.readLine()) != null)
				buffer.append(line);
			log.debug("fetchProfileData content: " + buffer.toString());
			return buffer.toString();
		} catch (Exception e) {
			log.debug("Failed to fetch profile data from facebook...", e);
		}
		return null;
	}

	protected boolean verifyAuthToken(String token, String uid, String fn, String ln) {
		if (StringUtils.isBlank(token) || StringUtils.isBlank(uid) 
				|| StringUtils.isBlank(fn) || StringUtils.isBlank(ln)) {
			return false;
		}
		String profileData = fetchProfileData(token);
		log.debug("fetchProfileData returned " + profileData);
		if (StringUtils.isBlank(profileData)) {
			return false;
		} else {
			try {
				JsonNode jsonNode = mapper.readTree(profileData);
				if (log.isDebugEnabled()) {
					log.debug("verifyAuthToken, processing jsonNode: " + jsonNode);
				}
				String userId = jsonNode.get("id").getTextValue();
				String firstName = jsonNode.get("first_name").getTextValue();
				String lastName = jsonNode.get("last_name").getTextValue();
				if (StringUtils.equals(uid, userId) && StringUtils.equals(fn, firstName) 
						&& StringUtils.equals(ln, lastName)) {
					log.debug("verifyAuthToken succeeded...");
					return true;
				}
			} catch (Exception e) {
				log.debug("Failed to verifyAuthToken...", e);
			}
		}
		return false;
	}
}
