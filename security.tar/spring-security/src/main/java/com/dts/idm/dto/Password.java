package com.dts.idm.dto;


import java.util.Date;

public class Password {
	private static final long serialVersionUID = 1L;
	private String pwd;
	private int userId;
	private Date modifiedAt = new Date();

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Date getModifiedAt() {
        return modifiedAt;
    }

    public void setModifiedAt(Date modifiedAt) {
        this.modifiedAt = modifiedAt;
    }
}
