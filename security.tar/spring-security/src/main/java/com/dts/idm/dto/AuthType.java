package com.dts.idm.dto;

public enum AuthType {
	NA("na"), OpenId("oid"), OAuth("oa"), UserPwd("up"), RoleBased("rb");
	
	private String code;
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	AuthType(String code) {
		this.code = code;
	}
	
	public static AuthType lookupByCode(String code) {
		for (AuthType s: AuthType.values()) {
			if (s.getCode().equals(code)) {
				return s;
			}
		}
		return NA;
	}
}
