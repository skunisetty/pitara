package com.dts.idm.service;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class ServiceException extends Exception {
	private static final long serialVersionUID = 1L;
	public static final ServiceException AUTHENTICATION_NEEDED = new ServiceException(ErrorMessage.AUTHENTICATE);
	public static final ServiceException CREDENTIAL_EXPIRED = new ServiceException(new ServiceException(ErrorMessage.AUTHENTICATE), "credential expired");
	public static final ServiceException BAD_CREDENTIAL = new ServiceException(new ServiceException(ErrorMessage.AUTHENTICATE), "bad credential");
	public static final ServiceException ACCESS_DENIED = new ServiceException(ErrorMessage.UNAUTHORIZED);
	public static final ServiceException SERVER_ERROR = new ServiceException(ErrorMessage.INTERNAL_ERROR);
	public static final ServiceException UNKNOWN_RESOURCE = new ServiceException(ErrorMessage.UNKNOWN_RESOURCE);
	public static final ServiceException BAD_REQUEST = new ServiceException(ErrorMessage.BAD_REQUEST);
	
	protected Set<ErrorMessage> errorCodes = new HashSet<ErrorMessage>();

	protected String message;
	
	public ServiceException() {
	}
	
	public ServiceException(ServiceException se) {
		this(se, se.getMessage());
	}
	
	public ServiceException(ServiceException se, String message) {
		this.errorCodes = se.errorCodes;
		this.message= message;
	}
	
	
	public ServiceException(ErrorMessage errorCode) {
		errorCodes.add(errorCode);
	}
	
	public Iterator<ErrorMessage> iterate() {
		return errorCodes.iterator();
	}	

	public Collection<ErrorMessage> errors() {
		return this.errorCodes;
	}
	
	public ServiceException setMessage(String message) {
		this.message = message;
		return this;
	}
	
	public ServiceException addErrorCode(ErrorMessage se) {
		this.errorCodes.add(se);
		return this;
	}

    public Set<ErrorMessage> getErrorCodes() {
        return errorCodes;
    }
}
