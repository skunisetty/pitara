package com.dts.idm.service;

import java.io.Serializable;

public class ErrorMessage implements Serializable {
	private static final long serialVersionUID = 1L;

	public enum ErrorCode {
		BAD_REQUEST(400, "Bad Request"),
		AUTHENTICATE(401, "Authenticate"), UNAUTHORIZED(403, "Unauthorized"), UNKNOWN_RESOURCE(
				404, "Unknown Resource"), INTERNAL_ERROR(500,
				"Internal Server Error"), NOT_SUPPORTED(501,
				"Unsupported Operation");
		private int code;
		int getCode() {
			return code;
		}

		String getMessage() {
			return message;
		}

		private String message;

		private ErrorCode(int i, String message) {
			this.code = i;
			this.message = message;
		}
	}

	public static final ErrorMessage BAD_REQUEST = new ErrorMessage(ErrorCode.BAD_REQUEST);
	public static final ErrorMessage AUTHENTICATE = new ErrorMessage(ErrorCode.AUTHENTICATE);
	public static final ErrorMessage UNAUTHORIZED = new ErrorMessage(ErrorCode.UNAUTHORIZED);
	public static final ErrorMessage UNKNOWN_RESOURCE = new ErrorMessage(ErrorCode.UNKNOWN_RESOURCE);
	public static final ErrorMessage INTERNAL_ERROR = new ErrorMessage(ErrorCode.INTERNAL_ERROR);
	public static final ErrorMessage NOT_SUPPORTED = new ErrorMessage(ErrorCode.NOT_SUPPORTED);

	private int code;
	private String message;

	public ErrorMessage() {
	}

	public ErrorMessage(ErrorCode code) {
		this.code = code.getCode();
		this.message = code.getMessage();
	}
	
	public ErrorMessage(ErrorCode code, String message) {
		this.code = code.getCode();
		this.message = message;
	}
}
