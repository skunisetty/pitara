package com.dts.idm.dto;

import java.util.Date;

public class RolePrivilege {
	private static final long serialVersionUID = 1L;
	private Role role;
	private Privilege privilege;
	private Date createdAt = new Date();

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Privilege getPrivilege() {
        return privilege;
    }

    public void setPrivilege(Privilege privilege) {
        this.privilege = privilege;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}
