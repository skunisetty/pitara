
package com.dts.idm.service;

import com.dts.idm.dto.Authorization;
import com.dts.idm.dto.User;

public interface TicketService {
    /** Creates a service ticket for a given Auth object and for predetermined ttl.
     *
     * @param auth The Authorization object for which the service ticket will be generated.
     * @return String form of ServiceTicket
     * @throws ServiceException
     */
	public String createServiceToken(Authorization auth)
			throws ServiceException;

    /**Validates the provided serviceTicket. The validation depends on a particular implementation.
     *
     * @param base64Encoded the string form of service ticket
     * @return the Authorization object that is encoded by the service ticket
     * @throws ServiceException
     */
	public Authorization validate(String base64Encoded) throws ServiceException;

    /**Create the service for the user provided as param and for predefined ttl.
     *
     * @param user the user for which the service ticket will be generated.
     * @return String form of the service ticket
     * @throws ServiceException
     */
	public String createServiceToken(User user) throws ServiceException;

    /** Creates a service ticket for a given user and for a precalculated ttl
     *
     * @param user
     * @param ttlInMin the service ticket will expire after millisec from generation time + ttlInMin
     * @return
     * @throws ServiceException
     */
	public String createServiceToken(User user, int ttlInMin) throws ServiceException;

    /** Decode the user information from the base64Encoded form of service ticket
     *
     * @param base64Encoded the service ticket
     * @return  the user object for whom the ticket was created
     * @throws ServiceException
     */
	public User extractUserInfo(String base64Encoded) throws ServiceException;

    /**This method should be called when its deemed necessary to invalidate the service token.
     * One of the use case is when user chooses to log out, the underlying service MUST call this
     * method in order for this service to remove it from registry.
     *
     *
     * @param base64Encoded
     * @throws ServiceException
     */
    public int invalidate(String base64Encoded) throws ServiceException;
}