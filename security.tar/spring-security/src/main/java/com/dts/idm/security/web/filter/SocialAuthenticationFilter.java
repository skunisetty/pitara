package com.dts.idm.security.web.filter;

import com.dts.common.StreamUtils;
import com.dts.idm.security.AuthScheme;
import com.dts.idm.security.OAuthAuthenticationToken;
import com.dts.idm.security.OAuthToken;
import com.dts.idm.security.web.ConstantsConsumer;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.ProviderNotFoundException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.codec.Base64;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

public class SocialAuthenticationFilter extends
		AbstractAuthenticationProcessingFilter implements ConstantsConsumer {
	private static final Log log = LogFactory
			.getLog(SocialAuthenticationFilter.class);
	
	private AuthScheme authScheme;

	private String credentialsCharset = "UTF-8";

	public SocialAuthenticationFilter() {
		this(DEFAULT_FILTER_PROCESSING_URL);
	}

	public SocialAuthenticationFilter(String defaultFilterProcessesUrl) {
		super(defaultFilterProcessesUrl);
	}

	@Override
	public Authentication attemptAuthentication(HttpServletRequest request,
			HttpServletResponse response) throws AuthenticationException,
			IOException, ServletException {
		log.debug("attemting Auth...");
		if (StringUtils.isBlank(request
				.getHeader(IDM_SECURITY_OAUTH_VERIFIED_KEY))) {
			return handleAuthentication(request, response);
		}
		return handleOAuth(request, response);
	}

	/**
	 * Basic and Digest auth will not be terminating in
	 * DEFAULT_FILTER_PROCESSING_URL so authentication is always true. For other
	 * case defer to super.
	 */
	@Override
	protected boolean requiresAuthentication(HttpServletRequest request,
			HttpServletResponse response) {
		Authentication existingAuth = SecurityContextHolder.getContext().getAuthentication();
		if (log.isDebugEnabled()) {
			log.debug("Authentication from SecurityContextHolder.getContext: " + existingAuth);
		}
		if(existingAuth != null && existingAuth.isAuthenticated()) {
            return false;
        }

		if (this.authScheme.equals(AuthScheme.FORM)) {
			return super.requiresAuthentication(request, response);
		}
		else if (this.authScheme.equals(AuthScheme.BASIC)) {
			String header = request.getHeader("Authorization");
			log.debug("handling basic auth ...header: " + header);

			if ((header != null) && header.startsWith("Basic ")) {
				return true;
			}
		}
		
		return false;
	}

	private Authentication handleOAuth(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String providerId = request.getHeader(IDM_SECURITY_OAUTH_PROVIDER_ID);
		log.debug("handling oAuth for provider: " + providerId);
		if (StringUtils.isBlank(providerId)) {
			throw new ProviderNotFoundException("provider null");
		}
		byte[] content = StreamUtils.getContent(request.getInputStream());
		if (log.isDebugEnabled()) {
			log.debug("the body of the post: " + new String(content));
		}
		OAuthToken at = new OAuthToken();
		at.setOAuthData(content);
                String accessToken = request.getParameter("access_token");
		log.debug("setting access token to : " + accessToken);
		if (StringUtils.isNotBlank(accessToken)) {
		    at.setToken(accessToken);
		}
		at.setServiceProviderId(providerId);
		
		return this.getAuthenticationManager().authenticate(new OAuthAuthenticationToken(at));
	}

	private Authentication handleAuthentication(HttpServletRequest request,
			HttpServletResponse response) throws AuthenticationException {
		log.debug("handling auth for scheme: " + this.authScheme);
		switch (this.authScheme) {
		case BASIC:
			return handleBasicAuth(request, response);
		case FORM:
			return handleFormAuth(request, response);
		}
		return null;
	}

	private Authentication handleFormAuth(HttpServletRequest request,
			HttpServletResponse response) {
		String username = request.getParameter(IDM_SECURITY_FORM_USERNAME_KEY);
		log.debug("handling form based auth for user: " + username);
		if (StringUtils.isBlank(username)) {
			throw new UsernameNotFoundException("No username specified");
		}
		String pwd = request.getParameter(IDM_SECURITY_FORM_PASSWORD_KEY);
		OAuthAuthenticationToken token = new OAuthAuthenticationToken(username,
				pwd);
		return this.getAuthenticationManager().authenticate(token);
	}

	private Authentication handleBasicAuth(HttpServletRequest request,
			HttpServletResponse response) {
		String header = request.getHeader("Authorization");
		log.debug("handling basic auth ...header: " + header);

		if ((header != null) && header.startsWith("Basic ")) {
			byte[] base64Token;
			try {
				base64Token = header.substring(6).getBytes("UTF-8");

				String token = new String(Base64.decode(base64Token),
						getCredentialsCharset(request));

				String username = "";
				String password = "";
				int delim = token.indexOf(":");

				if (delim != -1) {
					username = token.substring(0, delim);
					password = token.substring(delim + 1);
				}

				if (log.isDebugEnabled()) {
					logger
							.debug("Basic Authentication Authorization header found for user '"
									+ username + "'");
				}
				OAuthAuthenticationToken authToken = new OAuthAuthenticationToken(
						username, password);
				return this.getAuthenticationManager().authenticate(authToken);
			} catch (UnsupportedEncodingException e) {
				log.info("exception while handling basic auth: "
						+ e.getMessage());
				throw new BadCredentialsException("Unsupported encoding", e);
			}
		}
		throw new UsernameNotFoundException(
				"No authorization header found in request");
	}

	private String getCredentialsCharset(HttpServletRequest request) {
		return this.credentialsCharset;
	}

	public AuthScheme getAuthScheme() {
		return authScheme;
	}

	public void setAuthScheme(AuthScheme authScheme) {
		this.authScheme = authScheme;
	}
}
