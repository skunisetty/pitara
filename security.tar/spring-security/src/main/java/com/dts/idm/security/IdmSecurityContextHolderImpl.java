package com.dts.idm.security;

import com.dts.idm.service.IdmSecurityContextHolder;
import org.springframework.security.core.context.SecurityContextHolder;

public class IdmSecurityContextHolderImpl implements IdmSecurityContextHolder {

	@Override
	public Long getUserId() {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		
	    if (principal instanceof UserDetailsImpl) return ((UserDetailsImpl) principal).getUserId();
	
	    // principal object is either null or represents anonymous user -
	    // neither of which our domain User object can represent - so return null
	    return null;
	}
}
