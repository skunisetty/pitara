package com.dts.idm.auth;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;


public final class PRNGUtil {
    /**
     * Logger for reporting what happens during the demo.
     */
    private static final Log LOG = LogFactory.getLog(PRNGUtil.class);

    /**
     * The size of the symmetric key with which to encrypt the counter, in <em>bytes</em>.
     */
    private static final int KEY_SIZE = 16;

    /**
     * Our internal counter. This won't be directly visible; instead, we'll encrypt it with
     * {@link #counterCipher} to produce the pseudorandom value for {@link #nextValue()}. Assumed
     * to be at least {@code 2^(KEY_SIZE-1)} to make conversion to a {@code KEY_SIZE}-byte array
     * easy.
     */
    private BigInteger counter;

    /**
     * The cipher to use for encrypting {@link #counter}. Fully initialized in the constructor.
     */
    private final Cipher counterCipher;

    private static PRNGUtil PRNGUtil = new PRNGUtil();

    /**Creates the next pseudorandom number
     *
     * @return
     */
    static public byte[] next() {
        return PRNGUtil.nextValue();
    }

    private PRNGUtil() {
        // We've got a couple things that need cryptographic sources of randomness to be
        // initialized. Use whatever source the platform thinks is best for that.
        final SecureRandom rnd = new SecureRandom();

        // Generate a new key to use for encrypting the counter. Initialize the counter's cipher
        // with it so we'll be ready to go when demo() is called.
        //
        // It's important to specify "AES/ECB/NoPadding" rather than simply "AES" when initializing
        // the cipher. While it's a bad mode for encrypting messages, ECB is exactly what we want in
        // this case because the counter ensures that we always encrypt a new block each time. We
        // need to insist on not having any padding to prevent extra junk from being added to the
        // output values.
        //
        // Note that the key returned by keyGen() may be used to initialize the cipher directly:
        // there is no need to examine the raw bytes. Also note that it's absolutely critical that
        // the symmetric key never be recorded anywhere, including in the logs.
        try {
            final KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init((KEY_SIZE * 8), rnd);
            LOG.info("Initialized key generator");

            final SecretKey counterKey = keyGen.generateKey();
            counterCipher = Cipher.getInstance("AES/ECB/NoPadding");
            counterCipher.init(Cipher.ENCRYPT_MODE, counterKey);
            LOG.info("Initialized counter cipher");

            // Initialize the counter to a random value with a range as wide as our key size limit. Make
            // sure it's large enough that its byte array representation will at least fill an array of
            // the desired size. It's easier to truncate leading bits from a value too long than it is
            // to sign-extend a value that's too short.
            //
            // Note that because the counter is effectively a seed for an AES-based PRNG, we use
            // generateSeed() to ask for whatever data the SecureRandom implementation thinks is good
            // enough to seed itself (usually an OS entropy source).generateSeed() is really expensive,
            // so we want to call it only once during initialization and let the cipher do the rest of
            // the work.

            // This makes the data and converts it to a BigInteger...
            final byte[] counterInitData = rnd.generateSeed(KEY_SIZE);
            counter = new BigInteger(counterInitData);
            // ...and this makes sure it's at least as big as we need it to be.
            counter = counter.add(BigInteger.ONE.shiftLeft(KEY_SIZE * 8));

            if (LOG.isInfoEnabled()) {
                LOG.info("Initialized counter to "+ Hex.encodeHexString(counter.toByteArray()));
            }
        } catch (Exception e) {
            LOG.error("error initializing cipher", e);
            throw new RuntimeException("Error initializing cipher", e);
        }
    }

    /**
     * Generates an individual pseudorandom value using the internal counter and key.
     *
     * @return A byte array containing the generated value.
     */
    private byte[] nextValue() {
        // Grab the next counter.
        final byte[] rawCounter = incrementCounter();

        // Encrypt it to get a pseudo-random number of the same length. The Cipher class is not
        // thread-safe, so the encryption operation must be synchronized on the cipher instance.
        // Cipher instances could be pooled if this were a multi-threaded app and extremely high
        // throughput were desired.
        final byte[] encryptedCounter;

        synchronized (counterCipher) {
            try {
                // The counter may be a little longer than KEY_SIZE, so tell the cipher to only work on
                // the least significant bytes. Those are where the entropy is.
                encryptedCounter = counterCipher.doFinal(rawCounter, rawCounter.length - KEY_SIZE, KEY_SIZE);
            } catch (final GeneralSecurityException e) {
                // This should never happen, assuming that we initialize everything correctly and
                // maintain the counter sanely.
                LOG.error("Failed to encrypt counter", e);
                throw new AssertionError(e);
            }
        }

        return encryptedCounter;
    }

    /**
     * Increments {@link #counter} and returns its value in one atomic operation.
     *
     * @return The value of {@code counter} as a byte array. Assuming that {@code counter} was
     *         initialized correctly in the constructor, the array will always be at least
     *         {@link #KEY_SIZE} bytes long. It is possible for a slightly longer array to be
     *         returned.
     */
    private byte[] incrementCounter() {
        // Synchronize on the counter to ensure that no two threads ever read the same value out of
        // this.
        synchronized (counter) {
            // Get the current value of the counter (i.e., the seed of our PRNG).
            final byte[] counterBytes = counter.toByteArray();

            // NOTE: As long as the key stays secret, logging the counter probably isn't a problem,
            // though I don't recommend it in a real app just because it isn't needed. Since this is
            // just a demo app, it can't hurt.
            if (LOG.isInfoEnabled()) {
                LOG.info("Current counter: " + Hex.encodeHexString(counterBytes));
            }

            // Bump the counter up to the next value before we leave.
            counter = counter.add(BigInteger.ONE);

            return counterBytes;
        }
    }
}
