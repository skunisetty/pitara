package com.dts.idm.service;


import com.dts.idm.dto.Status;
import com.dts.idm.dto.User;

import java.util.Collection;
import java.util.List;

public interface UserService
{
	public Collection<String> checkAvailableIds(List<String> netId) throws ServiceException;

    /**Authenticate the user using the usrId (String, and not the database Id) and hashed password.
     * The password must be hashed using AuthUtil in order for this service to pass.
     *
     * @param usrId the String id - aka netId - of the user
     * @param pwd hashed password using AuthUtil
     * @return
     * @throws ServiceException
     */
	public User authenticate(String usrId, String pwd) throws ServiceException;
	public User createUserWithPassword(User user, String pwd) throws ServiceException;
	public User findUserByUserId(String userId) throws ServiceException;
	public Collection<User> findUsersByStatus(Status status) throws ServiceException;
	public int updateUserStatus(Collection<Long> idList, Status newStatus) throws ServiceException;
	public void changePassword(Long userDBId, String oldPassword, String newPassword) throws ServiceException;
	public void changePassword(String usersUserId, String oldPassword, String newPassword) throws ServiceException;
    public void resetPassword(String netId, String newPassword) throws ServiceException;
    public void resetPassword(Long userId, String password) throws ServiceException;
	public Collection<User> findUsersLike(String like);
	public User findUserCredentials(String usrId) throws ServiceException;

    User save(User usr) throws ServiceException;

    boolean delete(Long id) throws ServiceException;

    Collection<User> findAll() throws ServiceException;

    User findById(Long id) throws ServiceException;

    Collection<User> search(User criteria) throws ServiceException;
}
