package com.dts.idm.service;

import com.dts.idm.dto.AuthToken;
import com.dts.idm.dto.Resource;
import com.dts.idm.dto.UserResource;
import java.util.Collection;

public interface ResourceService {
	Collection<Resource> findAll() throws ServiceException;
	Resource findById(int resourceId) throws ServiceException;
	int delete(Collection<Integer> resourceIdList) throws ServiceException;
	Resource save(Resource resource) throws ServiceException;
	
	UserResource saveUserResource(UserResource userResource) throws ServiceException;
	int 				deleteUserResource(Collection<UserResource> userResource) throws ServiceException;
	Collection<UserResource> findUserResource(Long userId) throws ServiceException;
	Collection<UserResource> findUserResource(UserResource userResource) throws ServiceException;
	Collection<AuthToken>	 findUserAuthToken(Long userId) throws ServiceException;
	AuthToken			findUserAuthToken(UserResource userResource) throws ServiceException;
	AuthToken			updateUserAuthToken(UserResource userResource) throws ServiceException;
	Collection<Resource> findByName(String name) throws ServiceException;
	AuthToken 			 getConsumerToken(Integer resourceId) throws ServiceException;
	void 				 setConsumerToken(Integer resourceId, AuthToken authToken) throws ServiceException;
	int deleteUserResources(Long usrId) throws ServiceException;
	int deleteUserResources(String usrNetId) throws ServiceException;

    boolean delete(int id) throws ServiceException;

    Collection<Resource> search(Resource criteria)
            throws ServiceException;
}
