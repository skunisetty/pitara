package com.dts.idm.dto;

import java.util.Date;

public class Resource {
	private static final long serialVersionUID = 1L;
	private String name;
	private String uri;
	private Date createdAt =new Date();
	private AuthType authType = AuthType.NA;
	private Integer roleId;
	private Integer parentId;
	private String description;
	private String token;
	private String secret;
    private Long id;

    public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Resource[id=").append(this.getId()).append(", name=").append(
				this.name).append(", uri=").append(this.uri).append("]");
		return sb.toString();
	}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public AuthType getAuthType() {
        return authType;
    }

    public void setAuthType(AuthType authType) {
        this.authType = authType;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
