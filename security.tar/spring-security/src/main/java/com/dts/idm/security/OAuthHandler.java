package com.dts.idm.security;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;

public interface OAuthHandler {
	String getProviderId();
	UserDetails retrieveUser(OAuthToken token) throws AuthenticationException;
}
