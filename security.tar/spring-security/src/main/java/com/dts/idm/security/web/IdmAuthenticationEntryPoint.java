package com.dts.idm.security.web;

import com.dts.idm.security.AuthScheme;
import com.dts.idm.service.ErrorMessage;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.security.authentication.ProviderNotFoundException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.security.web.savedrequest.RequestCache;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class IdmAuthenticationEntryPoint implements ConstantsConsumer, AuthenticationEntryPoint,
		AuthenticationFailureHandler, InitializingBean {

	private static final Log log = LogFactory
			.getLog(IdmAuthenticationEntryPoint.class);

	private LoginUrlAuthenticationEntryPoint loginUrlAuthEntryPoint;
	private RequestCache requestCache = new HttpSessionRequestCache();
	private AuthScheme authScheme;
	private String realmName;

	@Override
	public void onAuthenticationFailure(HttpServletRequest request,
			HttpServletResponse response, AuthenticationException authException)
			throws IOException, ServletException {
		log.debug("onAuthenticationFailure!!! " + authException.getMessage());
		requestCache.saveRequest(request, response);
		switch (authScheme) {
		case BASIC:
			handleBasic(request, response, authException);
			return;
		case FORM:
			handleForm(request, response, authException);
			return;
		}
	}

	@Override
	public void commence(HttpServletRequest request,
			HttpServletResponse response, AuthenticationException authException)
			throws IOException, ServletException {
		log.debug("commence auth failure!!! " + authException.getMessage());
		this.onAuthenticationFailure(request, response, authException);
	}

	private void handleForm(HttpServletRequest request,
			HttpServletResponse response, AuthenticationException authException)
			throws IOException, ServletException {

		String ajax = request.getParameter(AJAX);
		try {
			if (ajax != null && Integer.parseInt(ajax) == 1) {
				Map<String, Object> model = new HashMap<String, Object>();
				model.put("errors", extractErrorMessage(authException));
				model.put("authentication", authException.getAuthentication());
				ObjectMapper mapper = new ObjectMapper();
				byte[] content = mapper.writeValueAsBytes(model);
				response.setHeader("j_idm_error", "401");
				response.setContentLength(content.length);
				response.setContentType(APPLICATION_JSON);
				response.getOutputStream().write(content);
				return;
			}
		} catch (NumberFormatException nfe) {
			log.warn("Error parsing ajax parameter value: " + ajax);
		}
		this.loginUrlAuthEntryPoint.commence(request, response, authException);
	}

	private ErrorMessage extractErrorMessage(
			AuthenticationException authException) {
		if (ProviderNotFoundException.class.isAssignableFrom(authException
				.getClass())) {
			return new ErrorMessage(ErrorMessage.ErrorCode.NOT_SUPPORTED,
					authException.getMessage());
		}

		return new ErrorMessage(ErrorMessage.ErrorCode.AUTHENTICATE,
				authException.getMessage());
	}

	private void handleBasic(HttpServletRequest request,
			HttpServletResponse response, AuthenticationException authException)
			throws IOException {
		log.debug("handling basic auth failure!");

		HttpServletResponse httpResponse = (HttpServletResponse) response;
		httpResponse.addHeader(WWW_AUTHENTICATE, "Basic realm=\"" + realmName
				+ "\"");
		httpResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED,
				authException.getMessage());
	}

	public AuthScheme getAuthScheme() {
		return authScheme;
	}

	public void setAuthScheme(AuthScheme authScheme) {
		this.authScheme = authScheme;
	}

	public String getRealmName() {
		return realmName;
	}

	public void setRealmName(String realmName) {
		this.realmName = realmName;
	}

	public void setLoginUrlAuthEntryPoint(
			LoginUrlAuthenticationEntryPoint loginUrlAuthEntryPoint) {
		this.loginUrlAuthEntryPoint = loginUrlAuthEntryPoint;
	}

	protected LoginUrlAuthenticationEntryPoint getLoginUrlAuthEntryPoint() {
		return loginUrlAuthEntryPoint;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		if (this.authScheme.equals(AuthScheme.BASIC)
				&& !StringUtils.hasText(this.realmName)) {
			throw new IllegalArgumentException("realmName not set!!!");
		}

		if (this.authScheme.equals(AuthScheme.FORM)) {
			Assert.notNull(this.loginUrlAuthEntryPoint,
					"loginUrlAuthEntryPoint not set!!!");
		}
	}
}
