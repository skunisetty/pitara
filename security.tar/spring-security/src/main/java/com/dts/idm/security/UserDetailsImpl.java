package com.dts.idm.security;

import com.dts.idm.dto.Status;
import com.dts.idm.dto.User;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.GrantedAuthorityImpl;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;


public class UserDetailsImpl implements UserDetails {
	private static final String ROLE_USER = "ROLE_USER";
	private static final long serialVersionUID = 1L;
	static final Collection<GrantedAuthority> DEF_AUTHORITIES = Collections
			.singleton((GrantedAuthority)new GrantedAuthorityImpl(ROLE_USER));

	private Collection<GrantedAuthority> authorities = new HashSet<GrantedAuthority>(DEF_AUTHORITIES);
	private User user;
	
	public User getUser() {
		return user;
	}

	public UserDetailsImpl(User user) {
		this.user = user;
	}
	
	public UserDetailsImpl(User user, Collection<String> roles) {
		this.user = user;
		for (String aRole: roles) {
			this.addAuthority(aRole);
		}
	}
	
	@Override
	public Collection<GrantedAuthority> getAuthorities() {
		return authorities;
	}

	@Override
	public String getPassword() {
		return null;
	}

	@Override
	public String getUsername() {
		return this.user.getUserId();
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return this.user.getStatus().equals(Status.ACTIVE);
	}
	
	void addAuthority(String role) {
		this.authorities.add(new GrantedAuthorityImpl(role));
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	
	public Long getUserId() {
		return this.user.getId();
	}
}
