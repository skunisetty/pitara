package com.dts.idm.dto;

public enum Status {
	ACTIVE("a"), INACTIVE("i"), LOCKED("l"), DISABLED("d"), PENDING("p");
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	Status(String code) {
		this.code = code;
	}
	
	private String code;
	
	public static Status lookupByCode(String code) {
		code = code.toLowerCase();
		for (Status s: Status.values()) {
			if (s.getCode().equals(code)) {
				return s;
			}
		}
		return PENDING;
	}
	
	public static Status byLabel(String label) {
		label = label.toUpperCase();
		for (Status s: Status.values()) {
			if (s.name().equals(label)) {
				return s;
			}
		}
		return PENDING;
	}
}
