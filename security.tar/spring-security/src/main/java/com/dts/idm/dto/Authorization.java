package com.dts.idm.dto;

import java.io.Serializable;
import java.util.Date;

public class Authorization implements Serializable {
	private static final long serialVersionUID = 1L;
	private Long userId;
	private String tenantId;
	private String principal;
	private int resourceId;
	private String resourceUrl;
	private Date startAt;
	private Date endAt;
	private String token;
	private String secret;
	private String ticket;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getPrincipal() {
        return principal;
    }

    public void setPrincipal(String principal) {
        this.principal = principal;
    }

    public int getResourceId() {
        return resourceId;
    }

    public void setResourceId(int resourceId) {
        this.resourceId = resourceId;
    }

    public String getResourceUrl() {
        return resourceUrl;
    }

    public void setResourceUrl(String resourceUrl) {
        this.resourceUrl = resourceUrl;
    }

    public Date getStartAt() {
        return startAt;
    }

    public void setStartAt(Date startAt) {
        this.startAt = startAt;
    }

    public Date getEndAt() {
        return endAt;
    }

    public void setEndAt(Date endAt) {
        this.endAt = endAt;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }

    public Authorization() {
	}
	
	public Authorization(AuthToken at) {
		this.userId = at.getUserId();
		this.token = at.getToken();
		this.secret = at.getSecret();
		this.principal = at.getPrincipal();
		this.startAt = at.getValidFrom();
		this.endAt = at.getValidTill();
	}
	
	public Authorization(Authorization at) {
		this.principal = at.principal;
		this.userId = at.userId;
		this.tenantId = at.tenantId;
		this.resourceId = at.resourceId;
		this.resourceUrl = at.resourceUrl;
		this.token = at.token;
		this.secret = at.secret;
		this.startAt = at.startAt;
		this.endAt = at.endAt;
		this.ticket = at.ticket;
	}
}
