package com.dts.idm.security;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;

public class OAuthAuthenticationToken extends UsernamePasswordAuthenticationToken {
	private static final long serialVersionUID = 1L;
	
	private OAuthToken oAuthToken;
	
	public OAuthAuthenticationToken(UserDetails ud) {
		super (ud, null, ud.getAuthorities());
		oAuthToken = new OAuthToken();
		oAuthToken.setPrincipal(ud.getUsername());
	}

	public OAuthAuthenticationToken(Object principal, Object credential) {
		super(principal, credential);
		this.setAuthenticated(false);
	}
	
	public OAuthAuthenticationToken(OAuthToken token) {
		this(token, UserDetailsImpl.DEF_AUTHORITIES);
	}
	
	public OAuthAuthenticationToken(OAuthToken authToken, Collection<GrantedAuthority> authorities) {
		super(authToken.getPrincipal(), authToken.getSecret(), authorities);
		this.oAuthToken = authToken;
		this.setAuthenticated(false);
	}
	
	public OAuthAuthenticationToken(UserDetails ud, OAuthToken oauthToken, Collection<GrantedAuthority> authorities) {
		super(ud, authorities);
		this.oAuthToken =oauthToken;
	}

    public OAuthToken getOAuthToken() {
		return oAuthToken;
	}
}
