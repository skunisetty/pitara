package com.dts.idm.security;


import com.dts.idm.dto.Status;
import com.dts.idm.dto.User;
import com.dts.idm.service.ServiceException;
import com.dts.idm.service.UserService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import javax.inject.Inject;

public class UserDetailsServiceImpl implements UserDetailsService {
	private static final Log log = LogFactory
			.getLog(UserDetailsServiceImpl.class);

	@Inject
	private UserService userService;
	private boolean createAccountIfAuthenticated;

	@Override
	public UserDetails loadUserByUsername(String userId)
			throws UsernameNotFoundException {
		if (log.isDebugEnabled()) {
			log.debug("loading user by username: " + userId);
		}
		UserDetails ud =null;
		User usr = null;
		try {
			usr = this.userService.findUserByUserId(userId);
		} catch (ServiceException e) {
			log.warn("no usr found by userId " + userId);
		}

		if (usr != null) {
			ud = new UserDetailsImpl(usr);
			if (log.isDebugEnabled()) {
				log.debug("userId: " + userId + ", userDetails: " + ud);
			}
		} else {
			if (this.createAccountIfAuthenticated) {
				usr = new User();
				usr.setFirstName(userId);
				usr.setLastName("");
				usr.setUserId(userId);
				usr.setStatus(Status.ACTIVE);
				try {
					this.userService.save(usr);
				} catch (ServiceException e) {
					String msg = "Error saving user: " + usr + " Details "
							+ e.getMessage();
					log.error(msg);
					throw new UsernameNotFoundException(msg, e);
				}
				ud = new UserDetailsImpl(usr);
			}
		}
		if (ud==null) {
				throw new UsernameNotFoundException(
						"Unknown userId " + userId);
		}
		return ud;
	}

	public void setCreateAccountIfAuthenticated(
			boolean createAccountIfAuthenticated) {
		this.createAccountIfAuthenticated = createAccountIfAuthenticated;
	}
}
