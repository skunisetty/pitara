package com.dts.idm.dto;

import java.util.Date;

public class UserGroup {
	private static final long serialVersionUID = 1L;
	private User user;
	private Group group;
	private Date createdAt = new Date();

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Group getGroup() {
        return group;
    }

    public void setGroup(Group group) {
        this.group = group;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}
