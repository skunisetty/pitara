package com.dts.idm.security.web;

import com.dts.idm.dto.User;
import com.dts.idm.security.OAuthAuthenticationToken;
import com.dts.idm.security.UserDetailsImpl;
import com.dts.idm.security.web.filter.SocialAuthenticationFilter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.security.web.savedrequest.RequestCache;
import org.springframework.security.web.savedrequest.SavedRequest;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class IdmAuthenticationSuccessHandler extends
		SavedRequestAwareAuthenticationSuccessHandler {
	private static final Log log = LogFactory.getLog(IdmAuthenticationSuccessHandler.class);
	
	private boolean contextRelative = true;
	private RequestCache requestCache = new HttpSessionRequestCache();

	@Override
	public void onAuthenticationSuccess(HttpServletRequest request,
			HttpServletResponse response, Authentication authentication)
			throws ServletException, IOException {
		if (OAuthAuthenticationToken.class.isAssignableFrom(authentication.getClass())) {
            OAuthAuthenticationToken oauth = (OAuthAuthenticationToken) authentication;
			User user = ((UserDetailsImpl) oauth.getPrincipal()).getUser();
			response.setHeader(
					SocialAuthenticationFilter.IDM_SECURITY_FORM_USERNAME_KEY,
					user.getFirstName());
			response.setHeader(
					SocialAuthenticationFilter.IDM_SECURITY_USER_ID_KEY, user
							.getId()
							+ "");
			response.setHeader(
					SocialAuthenticationFilter.IDM_SECURITY_PRINCIPAL_KEY, user
							.getUserId());

			String ajax = request.getParameter(ConstantsConsumer.AJAX);
			try {
				if (ajax != null && Integer.parseInt(ajax) == 1) {
					Map<String, Object> model = new HashMap<String, Object>();

					model.put("user", user);
					SavedRequest savedRequest = this.requestCache.getRequest(
							request, response);
					String targetUrl = null;
					if (savedRequest != null) {
						targetUrl = savedRequest.getRedirectUrl();
					} else {
						targetUrl = this.determineTargetUrl(request, response);

					}
					String redirectUrl = this.calculateRedirectUrl(request
							.getContextPath(), targetUrl);
					redirectUrl = response.encodeRedirectURL(redirectUrl);

					model.put("location", redirectUrl);

					ObjectMapper mapper = new ObjectMapper();
					byte[] content = mapper.writeValueAsBytes(model);
					response.setContentType(ConstantsConsumer.APPLICATION_JSON);
					response.setContentLength(content.length);
					response.getOutputStream().write(content);
					response.flushBuffer();
					return;
				}
			} catch (NumberFormatException nfe) {
				log.warn("Error parsing ajax parameter value: " + ajax);
			}
		}

		super.onAuthenticationSuccess(request, response, authentication);
	}

	private String calculateRedirectUrl(String contextPath, String url) {
		if (!url.startsWith("http://") && !url.startsWith("https://")) {
			if (contextRelative) {
				return url;
			} else {
				return contextPath + url;
			}
		}

		// Full URL, including http(s)://

		if (!contextRelative) {
			return url;
		}

		// Calculate the relative URL from the fully qualifed URL, minus the
		// protocol and base context.
		url = url.substring(url.indexOf("://") + 3); // strip off protocol
		url = url.substring(url.indexOf(contextPath) + contextPath.length());

		if (url.length() > 1 && url.charAt(0) == '/') {
			url = url.substring(1);
		}

		return url;
	}

	/**
	 * If <tt>true</tt>, causes any redirection URLs to be calculated minus the
	 * protocol and context path (defaults to <tt>false</tt>).
	 */
	public void setContextRelative(boolean useRelativeContext) {
		this.contextRelative = useRelativeContext;
	}

}
