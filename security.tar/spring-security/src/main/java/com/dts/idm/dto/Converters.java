package com.dts.idm.dto;

public abstract class Converters {
	static public AuthToken getAuthToken(Authorization auth) {
		AuthToken at = new AuthToken();
		at.setUserId(auth.getUserId());
		at.setPrincipal(auth.getPrincipal());
		at.setToken(auth.getToken());
		at.setSecret(auth.getSecret());
		at.setValidFrom(auth.getStartAt());
		at.setValidTill(auth.getEndAt());
		at.setResourceId(auth.getResourceId());
		return at;
	}
	
	static public Authorization getAuthorization(AuthToken auth) {
		Authorization at = new Authorization();
		at.setUserId(auth.getUserId());
		at.setPrincipal(auth.getPrincipal());
		at.setToken(auth.getToken());
		at.setSecret(auth.getSecret());
		at.setEndAt(auth.getValidTill());
		at.setStartAt(auth.getValidFrom());
		at.setResourceId(auth.getResourceId());
		
		return at;
	}
}
