package com.dts.idm.security.web;

public interface ConstantsConsumer {
	public static final String WWW_AUTHENTICATE = "WWW-Authenticate";
	public static final String APPLICATION_JSON = "application/json";
	public static final String AJAX = "ajax";
	
	public static final String IDM_SECURITY_FORM_USERNAME_KEY = "j_username";
	public static final String IDM_SECURITY_FORM_PASSWORD_KEY = "j_password";
	public static final String IDM_SECURITY_OAUTH_VERIFIED_KEY = "j_oauth_verified";
	public static final String IDM_SECURITY_OAUTH_PROVIDER_ID = "j_oauth_provider_id";
	public static final String IDM_SECURITY_OAUTH_DATA = "j_oauth_data";
	public static final String IDM_SECURITY_PASSWORD_HASHED_KEY = "j_pwhashed";
	public static final String IDM_SECURITY_SERVICE_TICKET_KEY = "_st";

	public static final String DEFAULT_FILTER_PROCESSING_URL = "/j_spring_security_check";
	public static final String IDM_SECURITY_USER_ID_KEY = "j_userid";
	public static final String IDM_SECURITY_PRINCIPAL_KEY = "j_principal";	
}
