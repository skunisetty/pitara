package com.dts.idm.service;

public class ServiceTicket {
    private String principal;
    private Integer resourceId;
    private String client;
    private String value;
    private Long createdAt;
    private Long expiresAt;

    public ServiceTicket() {
    }

    public ServiceTicket(String value) {
        this(value,null,null);
    }

    public ServiceTicket(String value, Long createdAt) {
       this(value,createdAt,null);
    }

    public ServiceTicket(String value, Long createdAt, Long expiresAt) {
        this.value = value;
        this.createdAt = createdAt;
        this.expiresAt = expiresAt;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getClient() {
        return client;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public int hashCode() {
        return this.value.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        try {
            ServiceTicket that = (ServiceTicket) o;
            return this.value.equals(that.value);
        } catch (ClassCastException cce) {
        }
        return false;
    }

    @Override
    public String toString() {
        return String.format("principal %s resId %s value %s for %s createdAt %s expiresAt %s", principal, resourceId, this.value, this.client, this.createdAt, this.expiresAt);
    }

    public Long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Long createdAt) {
        this.createdAt = createdAt;
    }

    public Long getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(Long expiresAt) {
        this.expiresAt = expiresAt;
    }

    public Integer getResourceId() {
        return resourceId;
    }

    public void setResourceId(Integer resourceId) {
        this.resourceId = resourceId;
    }

    public String getPrincipal() {
        return principal;
    }

    public void setPrincipal(String principal) {
        this.principal = principal;
    }
}
