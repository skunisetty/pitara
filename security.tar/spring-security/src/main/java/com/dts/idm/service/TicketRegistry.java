package com.dts.idm.service;


public interface TicketRegistry<T> {
    /** Register the given service ticket
     *
     * @param ticket
     */
	void register(T ticket);

    /**Unregister the given service ticket
     *
     * @param ticket
     */
	void unregister(T ticket);

    /**Lookup the given service ticket. A null will be returned if the lookup fails because the ticket is not found
     * or if underlying api fails
     *
     * @param ticket
     * @return Ticket if lookup successful else null
     */
	T lookup(T ticket);
}
