package com.dts.idm.auth;

import org.apache.commons.codec.binary.Base64;

import java.security.MessageDigest;

public class AuthUtil 
{
	// This needs to be in code. If its in database, all entries could be lost if this is corrupted
	// Algorithm does NOT depend on Global Salt being secret.
	private static byte[] GLOBAL_SALT = pack("C5BF891B4EF6AA79C3B0520D5DB9383F"); // sqrt π
	
	public static String hashPassword(String user, String password)
	throws Exception 
	{
		if (null==password) {
			password="";
		}
		MessageDigest md5, sha256;
		md5    = MessageDigest.getInstance("MD5");
		sha256 = MessageDigest.getInstance("SHA-256");
		byte[] userSalt = md5.digest( marshal(user.getBytes("UTF-8"), GLOBAL_SALT, password.getBytes("UTF-8")) );
		byte[] pwdHash  = sha256.digest(userSalt);
		return Base64.encodeBase64String(pwdHash).trim();
	}
	
	public static byte[] marshal(byte[] ... args)
	{
		int total = 0;
		for(int i = 0; i < args.length; i++)
			total += args[i].length;
		
		byte[] result = new byte[total];
		for(int i = 0, len = 0; i < args.length; len += args[i].length, i++)
		{
			System.arraycopy(args[i], 0, result, len, args[i].length);
		}
		return result;
	}

	public static byte[] pack(String hexString)
	{
		if(hexString.length() % 2 != 0)
		{
			throw new IllegalArgumentException("String to be packed needs even # of hex digits: " + hexString);
		}
		byte[] packed = new byte[hexString.length()/2];
		for(int i = 0; i < hexString.length(); i+=2)
		{
			int upperNibble = hexCharToInt(hexString.charAt(i));
			int lowerNibble = hexCharToInt(hexString.charAt(i+1));
			packed[i/2] = (byte) (upperNibble * 16 + lowerNibble) ; 
		}
		return packed;
	}
	
	public static int hexCharToInt(char hex)
	{
		int hexChar = hex & 0x40;
		return (hexChar >> 3) | (hexChar >> 6) + (hex & 0xF);
	}


}
