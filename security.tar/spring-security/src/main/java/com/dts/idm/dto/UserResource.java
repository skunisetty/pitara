package com.dts.idm.dto;

import java.util.Date;

public class UserResource {
	private static final long serialVersionUID = 1L;
	private Long id;
	private User user = new User();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Resource getResource() {
        return resource;
    }

    public void setResource(Resource resource) {
        this.resource = resource;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getNetId() {
        return netId;
    }

    public void setNetId(String netId) {
        this.netId = netId;
    }

    public AuthToken getAuthToken() {
        return authToken;
    }

    public void setAuthToken(AuthToken authToken) {
        this.authToken = authToken;
    }

    private Resource resource = new Resource();
	private Date createdAt =new Date();
	private String netId;
	private AuthToken authToken = new AuthToken();
	
	public UserResource() {
	}
	
	public UserResource(Long userId, Long resId) {
		this.user.setId(userId);
		this.resource.setId(resId);
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("UserResource[userId=").append(this.getUser().getId()).append(", resourceId=").append(
				this.getResource().getId()).append(", authToken=").append("]");
		return sb.toString();
	}
}
