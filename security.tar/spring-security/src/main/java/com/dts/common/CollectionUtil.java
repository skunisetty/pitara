package com.dts.common;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

public class CollectionUtil {
	private static final Logger log = LoggerFactory
			.getLogger(CollectionUtil.class);
	public static String[] EMPTY_STRING_ARRAY = new String[0];
	@SuppressWarnings("unchecked")
	public static List EMPTY_STRING_LIST = Collections.EMPTY_LIST;
	
	static public Properties split(String source, String regex) {
		Properties props = new Properties();
		if (StringUtils.isNotBlank(source)) {
			String[] parts = source.split(regex);
			for (String p: parts) {
				String[] kv =p.split("=");
				if (kv.length>1) {
					props.put(clean(kv[0]), clean(kv[1]));
				}
			}
		}
		return props;
	}

	private static String clean(String value) {
		if (value.startsWith("\"")) {
			value = value.substring(1);
		}
		if (value.endsWith("\"")) {
			value = value.substring(0, value.length()-1);
		}
		return value.trim();
	}

	static public <T> List<T> split(String source, String regex,
			String propName, Class<T> clz) {
		if (StringUtils.isBlank(source)) {
			return Collections.emptyList();
		}
		String[] parts = source.split(regex);
		List<T> list = new ArrayList<T>();

		Constructor<T> constructor = null;
		Method m = null;

		try {
			if (StringUtils.isBlank(propName)) {
				constructor = clz.getConstructor(String.class);
			} else {
				String setter = "set" + StringUtils.capitalize(propName);
				m = clz.getMethod(setter, String.class);
			}
		} catch (Exception e) {
			log.error(String.format("Error finding a suitable constructor or setter for class <%s> or propName <%s>",
					clz, propName), e);
			return list;
		}

		for (String ap : parts) {
			try {
				T instance = null;
				if (constructor != null) {
					instance = constructor.newInstance(ap);
				} else {
					instance = clz.newInstance();
					m.invoke(instance, ap);
				}
				if (instance != null) {
					list.add(instance);
				}
			} catch (Exception e) {
				log.warn(
						"Error creating object of type or setting the property "
								+ clz, e);
			}
		}
		return list;
	}
	
	static public boolean equals(Object[] left, Object[] right) {
		if (left!=null && right!=null) {
			if (left.length==right.length) {
				for (int i=0; i<left.length; ++i) {
					if (!left[i].equals(right[i])) {
						return false;
					}
				}
				return true;
			}
		}
		return false;
	}

	public static String merge(List<String> strList, String separator) {
		if (strList==null||strList.isEmpty()) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		for (int i=0; i< strList.size();++i) {
			sb.append(strList.get(i));
			if (i+1!=strList.size()) {
				sb.append(separator);
			}
		}
		
		return sb.toString();
	}
}
