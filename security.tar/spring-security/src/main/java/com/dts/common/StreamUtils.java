package com.dts.common;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class StreamUtils {
	public static byte[] getContent(InputStream is) throws IOException {
		byte[] chunk =new byte[256];
		int i=0;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		while ( (i=is.read(chunk))!=-1) {
			baos.write(chunk, 0,i);
		}
		return baos.toByteArray();
	}

	public static byte[] loadContent(String fileName) throws IOException {
		return getContent(StreamUtils.class.getClassLoader().getResourceAsStream(fileName));
	}
}
